#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QApplication>
#include <QDesktopWidget>
#include <QStringList>
#include <QDebug>
#include <getopt.h>
#include <iostream>
#include <QLabel>
#include <QPushButton>
#include <QVector>
#include <QSpacerItem>
#include <QFile>
#include <QRegExp>
#include <QProcess>
#include <QMenu>
#include <QAction>
#include <QProgressBar>
#include "console.h"
#include "config.h"
#include "supergetopt.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void PrintHelp();
    
private:
    Ui::MainWindow *ui;

    bool draw;

    quint32 h_size;
    quint8 align,pos;
    ConsoleReader console;
    QVector<QWidget*> lbl_list;

    QRegExp tag_rx;

    void BuildComponent(QString item, quint32 iter);
    QString ConsumeTag(QString p);
    QString ConsumeAllTags(QString p);
    QString GetTag(QString p);


public slots:
    void ReadyReadStdin(QString line);
    void ButtonExecute();

};

#endif // MAINWINDOW_H
