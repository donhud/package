#!/bin/sh
I=0
while true; do
	DATE=`date`;
	
	echo "[S][F]5|[M][/usr/share/icons/Tango/32x32/apps/kfm.png][Applicazioni][/usr/share/icons/Tango/32x32/apps/kfm.png][gnome-open /tmp]Calcolatrice|[B][S][/usr/share/icons/Tango/32x32/apps/kfm.png][gedit]Gedit|[S][F]10|[L][R]$DATE|[S][F]10|[B][R][ ][gnome-calculator]$DATE|[P][R][200]$I"
	I=$(($I + 10))
	I=$(($I % 110))
	sleep 1;
done
