#include "mainwindow.h"
#include "ui_mainwindow.h"

using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    tag_rx.setPattern("^\\[[^\\[\\]]+\\]");

    h_size = H_SIZE;
    align = ALIGN_LEFT;
    pos = POS_TOP;
    draw = false;

    int argPos;
    char opt_a = ' ', opt_p = ' ', opt_t = 0, opt_h = 0;

    int n = superGetOpt(qApp->argc(), qApp->argv(), &argPos,
                        "-a %c", &opt_a, "set alignment [l|c|r]",
                        "-p %c", &opt_p, "set position [t|b]",
                        "-h %d", &h_size, "set heigth <pixel>",
                        "-t", &opt_t, "set transparent background",
                    "-h", &opt_h, "qbar [-a <l|c|r>] [-p <t|b>] [-t] [-h <pixel>]",
                    (char * ) 0 );

    if(opt_a == 'l'){
        align = ALIGN_LEFT;
    } else if(opt_a == 'r') {
        align = ALIGN_RIGHT;
    } else if(opt_a == 'c') {
        align = ALIGN_CENTER;
    }

    if(opt_p == 't'){
        pos = POS_TOP;
    } else if(opt_p == 'b') {
        pos = POS_BOTTOM;
    }

    if( opt_h || (n < 0) ) {
            PrintHelp();
            exit(1);
    }

    if( opt_t ) {
        this->setAttribute(Qt::WA_TranslucentBackground, true);
    }

    connect(&console,SIGNAL(textReceived(QString)),this,SLOT(ReadyReadStdin(QString)));

    this->setWindowFlags(Qt::Tool|Qt::FramelessWindowHint|Qt::WindowStaysOnTopHint);

    if(pos == POS_TOP)
        this->setGeometry(0,0,qApp->desktop()->width(),h_size);
    else
        this->setGeometry(0,qApp->desktop()->height()-h_size,qApp->desktop()->width(),h_size);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::PrintHelp()
{
    std::cout <<  "qbar [-a <l|c|r>] [-p <t|b>] [-t] [-h <pixel>]" << endl;
}

void MainWindow::ReadyReadStdin(QString line)
{
    if(draw == false ){

        if((align == ALIGN_RIGHT) || (align == ALIGN_CENTER)) {
            QSpacerItem *s = new QSpacerItem(10,10,QSizePolicy::Expanding,QSizePolicy::Minimum);
            ui->container->addItem(s);
        }

        quint32 i = 0;
        foreach(QString val, line.split("|")) {
            BuildComponent(val,i);
            i+=1;
        }

        if((align == ALIGN_LEFT) || (align == ALIGN_CENTER)) {
            QSpacerItem *s = new QSpacerItem(10,10,QSizePolicy::Expanding,QSizePolicy::Minimum);
            ui->container->addItem(s);
        }

        draw = true;
    } else {
        quint32 i = 0;
        foreach(QString val, line.split("|")) {
            BuildComponent(val,i);
            i+=1;
        }
    }

}

void MainWindow::BuildComponent(QString item, quint32 iter)
{


    /******* LABEL **********/
    if(item.startsWith("[L]")) {


        item = ConsumeTag(item);

        if(draw == false) {

            item = ConsumeAllTags(item);

            QLabel *l = new QLabel();
            l->setObjectName("ITEM_"+QString::number(iter+1));
            l->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Expanding);
            l->setText(item);
            ui->container->addWidget(l);
            lbl_list.append(l);

        } else {


            if(item.startsWith("[R]")){
                item = ConsumeAllTags(item);
                qobject_cast<QLabel*>(lbl_list.at(iter))->setText(item);
            }

        }

    } else if(item.startsWith("[B]")) {

        item = ConsumeTag(item);

        if(draw == false) {

            QPushButton *l = new QPushButton();
            l->setObjectName("ITEM_"+QString::number(iter+1));
            l->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Expanding);

            ui->container->addWidget(l);
            l->setFocusPolicy(Qt::NoFocus);
            lbl_list.append(l);

            /* refresh */
            item = ConsumeTag(item);

            /* icon */
            QString icon = GetTag(item);
            if(QFile(icon).exists()) {
                l->setIcon(QIcon(icon));
                l->setIconSize(QSize(h_size,h_size));
            }
            item = ConsumeTag(item);

            /* command */
            QString command = GetTag(item);
            l->setProperty("command",command);
            item = ConsumeTag(item);

            item = ConsumeAllTags(item);
            l->setText(item);

            connect(l,SIGNAL(clicked()),this,SLOT(ButtonExecute()));

        } else {

            if(item.startsWith("[R]")){

                item = ConsumeAllTags(item);

                qobject_cast<QPushButton*>(lbl_list.at(iter))->setText(item);
            }
        }

    } else if(item.startsWith("[S]")) {

        if(draw)
            return;

        item = ConsumeTag(item);

        QSpacerItem *s = NULL;

        if(item.startsWith("[E]")) {
            s = new QSpacerItem(10,10,QSizePolicy::Expanding,QSizePolicy::Expanding);
        } else if(item.startsWith("[F]")) {
            item = ConsumeAllTags(item);
            s = new QSpacerItem(item.toInt(),10,QSizePolicy::Minimum,QSizePolicy::Expanding);
        }

        if(s) {
            ui->container->addItem(s);
            lbl_list.append(new QWidget());
        }

    } else if(item.startsWith("[M]")) {

        if(draw)
            return;

        item = ConsumeTag(item);

        QPushButton *l = new QPushButton();
        l->setObjectName("ITEM_"+QString::number(iter+1));
        l->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Expanding);


        l->setFocusPolicy(Qt::NoFocus);
        lbl_list.append(l);


        /* icon */
        QString icon = GetTag(item);
        if(QFile(icon).exists()) {
            l->setIcon(QIcon(icon));
            l->setIconSize(QSize(h_size,h_size));
        }

        item = ConsumeTag(item);
        l->setText(GetTag(item));
        item = ConsumeTag(item);

        QMenu *menu = new QMenu(l);


        foreach(QString v, item.split("*")) {

            QAction *a = new QAction(menu);
            a->setIconVisibleInMenu(true);
            /* icon */
            QString icon = GetTag(v);
            if(QFile(icon).exists()) {
                a->setIcon(QIcon(icon));
            }

            v = ConsumeTag(v);

            /* command */
            QString command = GetTag(v);
            a->setProperty("command",command);

            v = ConsumeAllTags(v);
            a->setText(v);

            connect(a,SIGNAL(triggered()),this,SLOT(ButtonExecute()));

            menu->addAction(a);

        }

        l->setMenu(menu);

        ui->container->addWidget(l);


    } else if(item.startsWith("[P]")) {


        item = ConsumeTag(item);

        if(draw == false) {

            item = ConsumeTag(item);

            QProgressBar *l = new QProgressBar();
            l->setRange(0,100);
            l->setObjectName("ITEM_"+QString::number(iter+1));
            l->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Expanding);

            int size = GetTag(item).toInt();
            item = ConsumeTag(item);

            l->setMinimumWidth(size);
            item = ConsumeAllTags(item);
            l->setValue(item.toInt());
            ui->container->addWidget(l);
            lbl_list.append(l);

        } else {

            if(item.startsWith("[R]")){
                item = ConsumeAllTags(item);
                qobject_cast<QProgressBar*>(lbl_list.at(iter))->setValue(item.toInt());
            }

        }

    }

}

QString MainWindow::ConsumeTag(QString p)
{
    return p.remove(tag_rx);
}

QString MainWindow::ConsumeAllTags(QString p)
{
    while(p.startsWith("[")) {
        p = ConsumeTag(p);
    }
    return p;
}

QString MainWindow::GetTag(QString p)
{
    QString pat = tag_rx.pattern();
    tag_rx.indexIn(p);
    QString ret = tag_rx.cap(0);
    ret.chop(1);
    ret.remove(0,1);
    tag_rx.setPattern(pat);

    return ret;
}

void MainWindow::ButtonExecute()
{
    QString cmd = sender()->property("command").toString() + "&";

    /*QProcess process;
    process.setProcessChannelMode(QProcess::SeparateChannels);
    process.startDetached(cmd);*/

    system(cmd.toAscii().data());


}

