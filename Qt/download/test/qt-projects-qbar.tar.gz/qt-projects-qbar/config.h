#ifndef CONFIG_H
#define CONFIG_H


#define H_SIZE 20

#define ALIGN_LEFT      0
#define ALIGN_RIGHT     1
#define ALIGN_CENTER    2

#define POS_TOP     0
#define POS_BOTTOM  1



/** PROTOCOL ***/
/*
 * MODE
 *
 * --------- LABEL --------
 * [L][R|S]<text>
 *
 * --------- BUTTON --------
 *
 * [B][R|S][<icon_path>][<command>]<text>
 *
 * --------- MENU --------
 *
 * [M][<icon_path>][<text>][<icon_path>][<command>]<text>*[<icon_path>][<command>]<text>...*[<icon_path>][<command>]<text>
 *
 * --------- SEPARATOR -----
 * [S][F|E]<size>
 *
 * [MODE][REFRESH]<applet> | <applet> | ... | <applet>
 *
 *
 * --------- PROGRESS -----
 * [P][S|R][<size>]<text>
 */


#endif // CONFIG_H
