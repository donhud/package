#ifndef DUTILS_H
#define DUTILS_H

#include <QObject>

class DUtils : public QObject
{
    Q_OBJECT
public:
    explicit DUtils(QObject *parent = 0);
    
signals:
    
public slots:
    
};

#endif // DUTILS_H
