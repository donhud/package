#ifndef WALLYPLUGINEXPORT_H
#define WALLYPLUGINEXPORT_H

#include "wallyplugin.h"

K_EXPORT_PLASMA_WALLPAPER(wallyplugin,WallyPlugin)

#endif
