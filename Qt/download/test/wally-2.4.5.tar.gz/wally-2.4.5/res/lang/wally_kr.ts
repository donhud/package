<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ko_KR">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../../src/about.cpp" line="47"/>
        <source>Compiled with:</source>
        <translation>Qt 버전:</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="49"/>
        <source>EXIF library:</source>
        <translation>EXIF 모듈:</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="52"/>
        <source>present</source>
        <translation>있음</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="54"/>
        <source>not present</source>
        <translation>없음</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="58"/>
        <source>English</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="60"/>
        <source>Italian</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="62"/>
        <source>Russian</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="64"/>
        <source>Spanish</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="66"/>
        <source>Portuguese (Brazil)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="68"/>
        <source>German</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="70"/>
        <source>French</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="72"/>
        <source>Czech</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="74"/>
        <source>Chinese (Simplified)</source>
        <translation>중국어 (간체)</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="76"/>
        <source>Chinese (Traditional)</source>
        <translation>중국어 (번체)</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="78"/>
        <source>Polish</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="80"/>
        <source>Catalan</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="82"/>
        <source>Greek</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="84"/>
        <source>Korean</source>
        <translation>한국어</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="86"/>
        <source>Hungarian</source>
        <translation>헝가리어</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="88"/>
        <source>Danish</source>
        <translation>덴마크어</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="90"/>
        <source>Swedish</source>
        <translation>스웨덴어</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="92"/>
        <source>Turkish</source>
        <translation>터키어</translation>
    </message>
    <message>
        <location filename="../../ui/about.ui" line="6"/>
        <source>About Wally</source>
        <translation>Wally에 대하여</translation>
    </message>
    <message>
        <location filename="../../ui/about.ui" line="65"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;/head&gt;&lt;body&gt;&lt;font size=&quot;+1&quot;&gt;Qt4 desktop wallpaper changer&lt;br /&gt;Author: Antonio Di Monaco (a.k.a. &lt;i&gt;Sin(x) &apos;76&lt;/i&gt;)&lt;br /&gt;I&apos;d like to thank Vincent Willem van Gogh for the logo :)&lt;br /&gt;&lt;br /&gt;Web site: &lt;a href=&quot;http://www.becrux.com&quot;&gt;http://www.becrux.com&lt;/a&gt;&lt;br /&gt;You can contact me at &lt;a href=&quot;mailto:tony@becrux.com?subject=About Wally&quot;&gt;tony@becrux.com&lt;/font&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;/head&gt;&lt;body&gt;&lt;font size=&quot;+1&quot;&gt;Qt4 바탕 화면 교체기&lt;br /&gt;제작자: Antonio Di Monaco (a.k.a. &lt;i&gt;Sin(x) &apos;76&lt;/i&gt;)&lt;br /&gt;로고에 대하여 Vincent Willem van Gogh에게 감사합니다 :)&lt;br /&gt;&lt;br /&gt;홈페이지: &lt;a href=&quot;http://www.becrux.com&quot;&gt;http://www.becrux.com&lt;/a&gt;&lt;br /&gt;연락처: &lt;a href=&quot;mailto:tony@becrux.com?subject=About Wally&quot;&gt;tony@becrux.com&lt;/font&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../ui/about.ui" line="94"/>
        <source>Details &gt;&gt;</source>
        <translation>자세히 &gt;&gt;</translation>
    </message>
    <message>
        <location filename="../../ui/about.ui" line="104"/>
        <source>Close</source>
        <translation>닫기</translation>
    </message>
    <message>
        <location filename="../../ui/about.ui" line="152"/>
        <source>Extension</source>
        <translation>확장자</translation>
    </message>
    <message>
        <location filename="../../ui/about.ui" line="157"/>
        <source>Description</source>
        <translation>설명</translation>
    </message>
    <message>
        <location filename="../../ui/about.ui" line="165"/>
        <source>Supported image formats:</source>
        <translation>지원되는 이미지 형식:</translation>
    </message>
    <message>
        <location filename="../../ui/about.ui" line="172"/>
        <source>Additional info:</source>
        <translation>추가 정보:</translation>
    </message>
    <message>
        <location filename="../../ui/about.ui" line="244"/>
        <source>Language</source>
        <translation>언어</translation>
    </message>
    <message>
        <location filename="../../ui/about.ui" line="249"/>
        <source>Translator</source>
        <translation>번역자</translation>
    </message>
    <message>
        <location filename="../../ui/about.ui" line="257"/>
        <source>Translations:</source>
        <translation>번역:</translation>
    </message>
</context>
<context>
    <name>Bing::DialogWidget</name>
    <message>
        <location filename="../../src/bing.cpp" line="304"/>
        <source>All of these words</source>
        <translation>모든 단어 포함</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="305"/>
        <source>Any of these words</source>
        <translation>일부 단어 포함</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="308"/>
        <source>Search for:</source>
        <translation>찾기:</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="314"/>
        <source>Strict</source>
        <translation>엄격</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="315"/>
        <source>Moderate</source>
        <translation>적당</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="316"/>
        <source>Off</source>
        <translation>끄기</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="319"/>
        <source>Adult filter:</source>
        <translation>성인물 필터:</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="342"/>
        <source>Bing item</source>
        <translation>Bing 항목</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="343"/>
        <source>Unfiltered content can show offending or sexual explicit photos</source>
        <translation>필터되지 않은 내용은 불쾌하거나 성적으로 노골적인 사진이 보일 수 있습니다.</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="354"/>
        <source>Edit Bing item</source>
        <translation>Bing 항목 편집</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="361"/>
        <source>Add Bing item</source>
        <translation>Bing 항목 추가</translation>
    </message>
</context>
<context>
    <name>Bing::Item</name>
    <message>
        <location filename="../../src/bing.cpp" line="56"/>
        <source>Tags:</source>
        <translation>태그:</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="58"/>
        <source>and</source>
        <translation>그리고</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="58"/>
        <source>or</source>
        <translation>또는</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="59"/>
        <source>Adult filter:</source>
        <translation>성인물 필터:</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="64"/>
        <source>Off</source>
        <translation>끄기</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="68"/>
        <source>Moderate</source>
        <translation>적당</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="73"/>
        <source>Strict</source>
        <translation>엄격</translation>
    </message>
</context>
<context>
    <name>Buzznet::DialogWidget</name>
    <message>
        <location filename="../../src/buzznet.cpp" line="225"/>
        <source>Search for:</source>
        <translation>찾기:</translation>
    </message>
    <message>
        <location filename="../../src/buzznet.cpp" line="248"/>
        <source>Edit Buzznet item</source>
        <translation>Buzznet 항목 편집</translation>
    </message>
    <message>
        <location filename="../../src/buzznet.cpp" line="253"/>
        <source>Add Buzznet item</source>
        <translation>Buzznet 항목 추가</translation>
    </message>
</context>
<context>
    <name>Buzznet::Item</name>
    <message>
        <location filename="../../src/buzznet.cpp" line="42"/>
        <source>Tag:</source>
        <translation>태그:</translation>
    </message>
</context>
<context>
    <name>DeviantArt::DialogWidget</name>
    <message>
        <location filename="../../src/deviantart.cpp" line="247"/>
        <source>Search for:</source>
        <translation>찾기:</translation>
    </message>
    <message>
        <location filename="../../src/deviantart.cpp" line="252"/>
        <source>Strict</source>
        <translation>엄격</translation>
    </message>
    <message>
        <location filename="../../src/deviantart.cpp" line="253"/>
        <source>Off</source>
        <translation>끄기</translation>
    </message>
    <message>
        <location filename="../../src/deviantart.cpp" line="256"/>
        <source>Adult filter:</source>
        <translation>성인물 필터:</translation>
    </message>
    <message>
        <location filename="../../src/deviantart.cpp" line="277"/>
        <source>deviantART item</source>
        <translation>deviantART 항목</translation>
    </message>
    <message>
        <location filename="../../src/deviantart.cpp" line="278"/>
        <source>Unfiltered content can show offending or sexual explicit photos</source>
        <translation>필터되지 않은 내용은 불쾌하거나 성적으로 노골적인 사진이 보일 수 있습니다</translation>
    </message>
    <message>
        <location filename="../../src/deviantart.cpp" line="289"/>
        <source>Edit deviantART item</source>
        <translation>deviantART 항목 편집</translation>
    </message>
    <message>
        <location filename="../../src/deviantart.cpp" line="295"/>
        <source>Add deviantART item</source>
        <translation>deviantART 항목 추가</translation>
    </message>
</context>
<context>
    <name>DeviantArt::Item</name>
    <message>
        <location filename="../../src/deviantart.cpp" line="43"/>
        <source>Tag:</source>
        <translation>태그:</translation>
    </message>
    <message>
        <location filename="../../src/deviantart.cpp" line="44"/>
        <source>Adult filter:</source>
        <translation>성인물 필터:</translation>
    </message>
    <message>
        <location filename="../../src/deviantart.cpp" line="49"/>
        <source>Off</source>
        <translation>끄기</translation>
    </message>
    <message>
        <location filename="../../src/deviantart.cpp" line="54"/>
        <source>Strict</source>
        <translation>엄격</translation>
    </message>
</context>
<context>
    <name>Exif::InfoDialog</name>
    <message>
        <location filename="../../src/exif.cpp" line="260"/>
        <source>EXIF information</source>
        <translation>EXIF 정보</translation>
    </message>
    <message>
        <location filename="../../src/exif.cpp" line="274"/>
        <source>Tag</source>
        <translation>태그</translation>
    </message>
    <message>
        <location filename="../../src/exif.cpp" line="275"/>
        <source>Value</source>
        <translation>값</translation>
    </message>
    <message>
        <location filename="../../src/exif.cpp" line="298"/>
        <source>No EXIF information available</source>
        <translation>EXIF 정보 없음</translation>
    </message>
</context>
<context>
    <name>Files::Core</name>
    <message>
        <location filename="../../src/files.cpp" line="145"/>
        <source>Loading folder...</source>
        <translation>폴더 읽는 중...</translation>
    </message>
</context>
<context>
    <name>Files::LabelPreview</name>
    <message>
        <location filename="../../src/files.cpp" line="261"/>
        <source>No preview available</source>
        <translation>미리보기 없음</translation>
    </message>
</context>
<context>
    <name>Files::SettingsWidget</name>
    <message>
        <location filename="../../src/files.cpp" line="281"/>
        <location filename="../../src/files.cpp" line="334"/>
        <source>Select a photo</source>
        <translation>사진 선택</translation>
    </message>
    <message>
        <location filename="../../src/files.cpp" line="297"/>
        <location filename="../../src/files.cpp" line="302"/>
        <source>Select a folder</source>
        <translation>폴더 선택</translation>
    </message>
</context>
<context>
    <name>FilesSettingsWidget</name>
    <message>
        <location filename="../../ui/files.ui" line="15"/>
        <source>Photos</source>
        <translation>사진</translation>
    </message>
    <message>
        <location filename="../../ui/files.ui" line="39"/>
        <source>Add a photo</source>
        <translation>사진 추가</translation>
    </message>
    <message>
        <location filename="../../ui/files.ui" line="59"/>
        <source>Add photos in folder</source>
        <translation>폴더에 있는 사진 추가</translation>
    </message>
    <message>
        <location filename="../../ui/files.ui" line="82"/>
        <source>Delete photo</source>
        <translation>사진 삭제</translation>
    </message>
    <message>
        <location filename="../../ui/files.ui" line="118"/>
        <source>Move photo up</source>
        <translation>위로 이동</translation>
    </message>
    <message>
        <location filename="../../ui/files.ui" line="141"/>
        <source>Move photo down</source>
        <translation>아래로 이동</translation>
    </message>
</context>
<context>
    <name>Flickr::DialogWidget</name>
    <message>
        <location filename="../../src/flickr.cpp" line="395"/>
        <source>All of these words</source>
        <translation>모든 단어 포함</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="396"/>
        <source>Any of these words</source>
        <translation>일부 단어 포함</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="400"/>
        <source>Search for:</source>
        <translation>찾기:</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="404"/>
        <source>Full text</source>
        <translation>전체 텍스트 검색</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="405"/>
        <source>Tags only</source>
        <translation>태그에서만 검색</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="413"/>
        <source>Largest</source>
        <translation>가장 큰 크기</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="414"/>
        <source>Original</source>
        <translation>원래 크기</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="415"/>
        <source>Large</source>
        <translation>큰 크기</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="416"/>
        <source>Medium</source>
        <translation>중간 크기</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="417"/>
        <source>Small</source>
        <translation>작은 크기</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="418"/>
        <source>Thumbnail</source>
        <translation>썸내일</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="419"/>
        <source>Square</source>
        <translation>정사각형</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="420"/>
        <source>Smallest</source>
        <translation>가장 작은 크기</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="425"/>
        <source>Interestingness desc</source>
        <translation>관심순 내림차순</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="426"/>
        <source>Relevance</source>
        <translation>관련성</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="427"/>
        <source>Date posted desc</source>
        <translation>올린 일시순 내림차순</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="428"/>
        <source>Date taken desc</source>
        <translation>찍은 일시순 내림차순</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="429"/>
        <source>Interestingness asc</source>
        <translation>관심순 올림차순</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="430"/>
        <source>Date posted asc</source>
        <translation>올린 일시순 올림차순</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="431"/>
        <source>Date taken asc</source>
        <translation>찍은 일시순 올림차순</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="434"/>
        <source>Size:</source>
        <translation>크기:</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="436"/>
        <source>Order:</source>
        <translation>정렬:</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="478"/>
        <source>Edit Flickr item</source>
        <translation>Flickr 항목 편집</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="496"/>
        <source>Add Flickr item</source>
        <translation>Flickr 항목 추가</translation>
    </message>
</context>
<context>
    <name>Flickr::Item</name>
    <message>
        <location filename="../../src/flickr.cpp" line="58"/>
        <source>Text:</source>
        <translation>검색어:</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="60"/>
        <source>Tags:</source>
        <translation>태그:</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="61"/>
        <source>and</source>
        <translation>그리고</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="62"/>
        <source>or</source>
        <translation>또는</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="66"/>
        <source>Size:</source>
        <translation>크기:</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="69"/>
        <source>Largest</source>
        <translation>가장 큰 크기</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="70"/>
        <source>Original</source>
        <translation>원래 크기</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="71"/>
        <source>Large</source>
        <translation>큰 크기</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="72"/>
        <source>Medium</source>
        <translation>중간 크기</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="73"/>
        <source>Small</source>
        <translation>작은 크기</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="74"/>
        <source>Thumbnail</source>
        <translation>썸내일</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="75"/>
        <source>Square</source>
        <translation>정사각형</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="76"/>
        <source>Smallest</source>
        <translation>가장 작은 크기</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="79"/>
        <source>Order:</source>
        <translation>정렬:</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="82"/>
        <source>Interestingness desc</source>
        <translation>관심순 내림차순</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="83"/>
        <source>Relevance</source>
        <translation>관련성</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="84"/>
        <source>Date posted desc</source>
        <translation>올린 일시순 내림차순</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="85"/>
        <source>Date taken desc</source>
        <translation>찍은 일시순 내림차순</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="86"/>
        <source>Interestingness asc</source>
        <translation>관심순 올림차순</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="87"/>
        <source>Date posted asc</source>
        <translation>올린 일시순 올림차순</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="88"/>
        <source>Date taken asc</source>
        <translation>찍은 일시순 올림차순</translation>
    </message>
</context>
<context>
    <name>Folders::DialogWidget</name>
    <message>
        <location filename="../../src/folders.cpp" line="447"/>
        <location filename="../../src/folders.cpp" line="456"/>
        <source>Local</source>
        <translation>로컬</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="448"/>
        <location filename="../../src/folders.cpp" line="479"/>
        <source>Remote</source>
        <translation>원격</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="463"/>
        <source>Include subfolders</source>
        <translation>하위폴더 포함</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="469"/>
        <source>Folder:</source>
        <translation>폴더:</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="488"/>
        <source>Passive</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="489"/>
        <source>Active</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="501"/>
        <source>Server:</source>
        <translation>서버:</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="503"/>
        <source>Port:</source>
        <translation>포트:</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="505"/>
        <source>Transfer mode:</source>
        <translation>전송 방식:</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="507"/>
        <source>Username:</source>
        <translation>계정:</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="509"/>
        <source>Password:</source>
        <translation>암호:</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="511"/>
        <source>Path:</source>
        <translation>경로:</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="534"/>
        <location filename="../../src/folders.cpp" line="539"/>
        <source>Select a folder</source>
        <translation>폴더 선택</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="588"/>
        <source>Edit folder</source>
        <translation>폴더 편집</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="614"/>
        <source>Add folder</source>
        <translation>폴더 추가</translation>
    </message>
</context>
<context>
    <name>Folders::LocalItem</name>
    <message>
        <location filename="../../src/folders.cpp" line="149"/>
        <source>(with subfolders)</source>
        <translation>(하위폴더 포함)</translation>
    </message>
</context>
<context>
    <name>Folders::RemoteItem</name>
    <message>
        <location filename="../../src/folders.cpp" line="253"/>
        <source>Transfer mode:</source>
        <translation>전송 방식:</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="254"/>
        <source>passive</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="254"/>
        <source>active</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>FoldersSettingsWidget</name>
    <message>
        <location filename="../../ui/folders.ui" line="15"/>
        <source>Folders</source>
        <translation>폴더</translation>
    </message>
    <message>
        <location filename="../../ui/folders.ui" line="26"/>
        <source>Add a folder</source>
        <translation>폴더 추가</translation>
    </message>
    <message>
        <location filename="../../ui/folders.ui" line="49"/>
        <source>Delete folder</source>
        <translation>폴더 삭제</translation>
    </message>
</context>
<context>
    <name>Google::DialogWidget</name>
    <message>
        <location filename="../../src/google.cpp" line="347"/>
        <source>Search for:</source>
        <translation>찾기:</translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="352"/>
        <source>Strict</source>
        <translation>엄격</translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="353"/>
        <source>Moderate</source>
        <translation>적당</translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="354"/>
        <source>Off</source>
        <translation>끄기</translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="357"/>
        <source>Adult filter:</source>
        <translation>성인물 필터:</translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="378"/>
        <source>Google item</source>
        <translation>Google 항목</translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="379"/>
        <source>Unfiltered content can show offending or sexual explicit photos</source>
        <translation>필터되지 않은 내용은 불쾌하거나 성적으로 노골적인 사진이 보일 수 있습니다.</translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="390"/>
        <source>Edit Google item</source>
        <translation>Google 항목 편집</translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="396"/>
        <source>Add Google item</source>
        <translation>Google 항목 추가</translation>
    </message>
</context>
<context>
    <name>Google::Item</name>
    <message>
        <location filename="../../src/google.cpp" line="55"/>
        <source>Text:</source>
        <translation>검색어:</translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="56"/>
        <source>Adult filter:</source>
        <translation>성인물 필터:</translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="61"/>
        <source>Off</source>
        <translation>끄기</translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="65"/>
        <source>Moderate</source>
        <translation>적당</translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="70"/>
        <source>Strict</source>
        <translation>엄격</translation>
    </message>
</context>
<context>
    <name>Gui::ColorButton</name>
    <message>
        <location filename="../../src/gui.cpp" line="132"/>
        <location filename="../../src/gui.cpp" line="140"/>
        <source>Auto</source>
        <translation>자동</translation>
    </message>
</context>
<context>
    <name>History::Dialog</name>
    <message>
        <location filename="../../src/history.cpp" line="364"/>
        <source>Right-click on items to show options</source>
        <translation>옵션을 보려면 항목에 오른클릭을 하세요.</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="395"/>
        <location filename="../../src/history.cpp" line="596"/>
        <location filename="../../src/history.cpp" line="613"/>
        <source>History</source>
        <translation>기록</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="440"/>
        <source>Please wait...</source>
        <translation>기다려 주세요...</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="441"/>
        <source>Downloading photo...</source>
        <translation>사진 받는 중...</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="442"/>
        <source>Abort</source>
        <translation>그만 두기</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="454"/>
        <location filename="../../src/history.cpp" line="458"/>
        <source>Save photo</source>
        <translation>사진 저장</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="456"/>
        <location filename="../../src/history.cpp" line="461"/>
        <source>Images (*.png *.xpm *.jpg)</source>
        <translation>사진 (*.png *.xpm *.jpg)</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="596"/>
        <source>Photo has been saved</source>
        <translation>사진이 저장되었습니다.</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="613"/>
        <source>There was an error during download</source>
        <translation>받아오는 중 오류가 발생하였습니다.</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="663"/>
        <source>View photo...</source>
        <translation>사진 보기...</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="667"/>
        <source>Get EXIF info...</source>
        <translation>EXIF 정보 보기...</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="671"/>
        <source>Save photo...</source>
        <translation>사진 저장...</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="675"/>
        <source>Set as background</source>
        <translation>바탕 화면으로 지정</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="679"/>
        <source>Explore image source</source>
        <translation>원본 보기</translation>
    </message>
</context>
<context>
    <name>History::EngineQueryModel</name>
    <message>
        <location filename="../../src/history.cpp" line="70"/>
        <source>All</source>
        <translation>모두</translation>
    </message>
</context>
<context>
    <name>History::PhotosQueryModel</name>
    <message>
        <location filename="../../src/history.cpp" line="238"/>
        <source>(no title)</source>
        <translation>(제목 없음)</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="240"/>
        <source>by:</source>
        <translation>올린 이:</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="241"/>
        <source>(no author)</source>
        <translation>(저자 없음)</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="243"/>
        <source>Date:</source>
        <translation>시각:</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="245"/>
        <source>Location:</source>
        <translation>위치:</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="246"/>
        <source>unknown</source>
        <translation>알 수 없음</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="248"/>
        <source>Size:</source>
        <translation>크기:</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="250"/>
        <source>Image size:</source>
        <translation>사진 크기:</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="252"/>
        <source>Engine:</source>
        <translation>엔진:</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="253"/>
        <source>EXIF:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="253"/>
        <source>No</source>
        <translation>없음</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="253"/>
        <source>Yes</source>
        <translation>있음</translation>
    </message>
</context>
<context>
    <name>History::TagsQueryModel</name>
    <message>
        <location filename="../../src/history.cpp" line="99"/>
        <source>All</source>
        <translation>모두</translation>
    </message>
</context>
<context>
    <name>HttpEngine::SettingsWidget</name>
    <message>
        <location filename="../../src/httpengine.cpp" line="656"/>
        <location filename="../../src/httpengine.cpp" line="661"/>
        <source>Select a folder</source>
        <translation>폴더 선택</translation>
    </message>
</context>
<context>
    <name>HttpSettingsWidget</name>
    <message>
        <location filename="../../ui/http.ui" line="12"/>
        <source>Photo sets</source>
        <translation>사진 모음</translation>
    </message>
    <message>
        <location filename="../../ui/http.ui" line="20"/>
        <source>Add a photo set</source>
        <translation>사진 모음 추가</translation>
    </message>
    <message>
        <location filename="../../ui/http.ui" line="43"/>
        <source>Delete photo set</source>
        <translation>사진 모음 삭제</translation>
    </message>
    <message>
        <location filename="../../ui/http.ui" line="97"/>
        <source>Options</source>
        <translation>설정</translation>
    </message>
    <message>
        <location filename="../../ui/http.ui" line="103"/>
        <source>Save photos</source>
        <translation>사진 저장</translation>
    </message>
</context>
<context>
    <name>Ipernity::DialogWidget</name>
    <message>
        <location filename="../../src/ipernity.cpp" line="284"/>
        <source>All of these words</source>
        <translation>모든 단어 포함</translation>
    </message>
    <message>
        <location filename="../../src/ipernity.cpp" line="285"/>
        <source>Any of these words</source>
        <translation>일부 단어 포함</translation>
    </message>
    <message>
        <location filename="../../src/ipernity.cpp" line="288"/>
        <source>Search for:</source>
        <translation>찾기:</translation>
    </message>
    <message>
        <location filename="../../src/ipernity.cpp" line="292"/>
        <source>Full text</source>
        <translation>전체 텍스트 검색</translation>
    </message>
    <message>
        <location filename="../../src/ipernity.cpp" line="293"/>
        <source>Tags only</source>
        <translation>태그에서만 검색</translation>
    </message>
    <message>
        <location filename="../../src/ipernity.cpp" line="309"/>
        <source>Ipernity item</source>
        <translation>Ipernity 항목</translation>
    </message>
    <message>
        <location filename="../../src/ipernity.cpp" line="310"/>
        <source>It can show offending or sexual explicit photos</source>
        <translation>불쾌하거나 성적으로 노골적인 사진이 보여질 수 있습니다.</translation>
    </message>
    <message>
        <location filename="../../src/ipernity.cpp" line="331"/>
        <source>Edit Ipernity item</source>
        <translation>Ipernity 항목 편집</translation>
    </message>
    <message>
        <location filename="../../src/ipernity.cpp" line="347"/>
        <source>Add Ipernity item</source>
        <translation>Ipernity 항목 추가</translation>
    </message>
</context>
<context>
    <name>Ipernity::Item</name>
    <message>
        <location filename="../../src/ipernity.cpp" line="57"/>
        <source>Text:</source>
        <translation>검색어:</translation>
    </message>
    <message>
        <location filename="../../src/ipernity.cpp" line="58"/>
        <location filename="../../src/ipernity.cpp" line="63"/>
        <source>and</source>
        <translation>그리고</translation>
    </message>
    <message>
        <location filename="../../src/ipernity.cpp" line="59"/>
        <location filename="../../src/ipernity.cpp" line="64"/>
        <source>or</source>
        <translation>또는</translation>
    </message>
    <message>
        <location filename="../../src/ipernity.cpp" line="66"/>
        <source>Tags:</source>
        <translation>태그:</translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../../src/main.cpp" line="65"/>
        <source>Error</source>
        <translation>오류</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="66"/>
        <source>Another instance of</source>
        <translation>이미</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="68"/>
        <source>is already running</source>
        <translation>가 실행 중입니다.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="77"/>
        <source>Disclaimer</source>
        <translation>책임 부인</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="78"/>
        <source>&lt;b&gt;The Author takes no responsibility over the content that Wally downloads from photo sharing web sites.&lt;br&gt;The Author is in no way responsible for any such content.&lt;/b&gt;&lt;br&gt;&lt;br&gt;If this is a problem for you, please use only local engines like &quot;Files&quot; or local &quot;Folders&quot;.&lt;br&gt;Otherwise, please select &lt;b&gt;&quot;No&quot;&lt;/b&gt; to exit Wally, or use it &lt;b&gt;at your own risk.&lt;/b&gt;&lt;br&gt;&lt;br&gt;(If you proceed, this message will appear only once)&lt;br&gt;&lt;br&gt;Do you accept the above condition?</source>
        <translation>&lt;b&gt;제작자는 Wally가 인터넷에 공유된 사진을 받아온 내용에 대하여 책임을 지지 않습니다.&lt;br&gt;제작자는 그런 내용에 대하여 책임질 방법이 없습니다.&lt;/b&gt;&lt;br&gt;&lt;br&gt;만약 이것이 문제가 된다면, &quot;파일&quot;이나 &quot;폴더&quot;같은 로컬 엔진을 사용하십시오.&lt;br&gt;아니면, &lt;b&gt;&quot;아니오&quot;&lt;/b&gt;를 선택하여 Wally를 종료하거나, &lt;b&gt;사용자 스스로의 책임으로&lt;/b&gt; 사용하십시오.&lt;br&gt;&lt;br&gt;(계속 진행한다면, 이 메세지는 이번에만 보입니다.)&lt;br&gt;&lt;br&gt;위 조건에 동의하십니까?</translation>
    </message>
</context>
<context>
    <name>Map::View</name>
    <message>
        <location filename="../../src/mapviewer.cpp" line="387"/>
        <source>Drag to select. Right-click to zoom</source>
        <translation>드래그하여 영역을 선택하세요. 오른클릭하여 확대할 수 있습니다.</translation>
    </message>
    <message>
        <location filename="../../src/mapviewer.cpp" line="395"/>
        <source>Zoom %1x</source>
        <translation>%1배 확대</translation>
    </message>
</context>
<context>
    <name>Map::Viewer</name>
    <message>
        <location filename="../../src/mapviewer.cpp" line="434"/>
        <source>Map viewer</source>
        <translation>지도 보기</translation>
    </message>
</context>
<context>
    <name>Panoramio::DialogWidget</name>
    <message>
        <location filename="../../src/panoramio.cpp" line="322"/>
        <source>Select on map</source>
        <translation>지도 선택</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="328"/>
        <source>Longitude (min):</source>
        <translation>경도 (최소):</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="330"/>
        <source>Longitude (max):</source>
        <translation>경도 (최대):</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="332"/>
        <source>Latitude (min):</source>
        <translation>위도 (최소):</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="334"/>
        <source>Latitude (max):</source>
        <translation>위도 (최대):</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="352"/>
        <source>Popularity</source>
        <translation>인기도</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="353"/>
        <source>Upload date</source>
        <translation>올린 일시</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="358"/>
        <source>Original</source>
        <translation>원래 크기</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="359"/>
        <source>Medium</source>
        <translation>중간 크기</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="360"/>
        <source>Small</source>
        <translation>작은 크기</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="361"/>
        <source>Thumbnail</source>
        <translation>썸내일</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="362"/>
        <source>Square</source>
        <translation>정사각형</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="363"/>
        <source>Mini square</source>
        <translation>작은 정사각형</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="366"/>
        <source>Order:</source>
        <translation>정렬:</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="367"/>
        <source>Size:</source>
        <translation>크기:</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="414"/>
        <source>Edit Panoramio item</source>
        <translation>Panoramio 항목 편집</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="427"/>
        <source>Add Panoramio item</source>
        <translation>Panoramio 항목 추가</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="435"/>
        <source>Error</source>
        <translation>오류</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="435"/>
        <source>Coordinates must be different</source>
        <translation>좌표가 달라야 합니다.</translation>
    </message>
</context>
<context>
    <name>Panoramio::Item</name>
    <message>
        <location filename="../../src/panoramio.cpp" line="185"/>
        <source>lat:</source>
        <translation>위도:</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="186"/>
        <source>lon:</source>
        <translation>경도:</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="284"/>
        <source>Original</source>
        <translation>원래 크기</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="285"/>
        <source>Medium</source>
        <translation>중간 크기</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="286"/>
        <source>Small</source>
        <translation>작은 크기</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="287"/>
        <source>Thumbnail</source>
        <translation>썸내일</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="288"/>
        <source>Square</source>
        <translation>정사각형</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="289"/>
        <source>Mini square</source>
        <translation>작은 정사각형</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="294"/>
        <source>Popularity</source>
        <translation>인기</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="295"/>
        <source>Upload date</source>
        <translation>올린 일시</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="298"/>
        <source>Longitude:</source>
        <translation>경도:</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="301"/>
        <source>Latitude:</source>
        <translation>위도:</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="304"/>
        <source>Size:</source>
        <translation>크기:</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="305"/>
        <source>Order:</source>
        <translation>정렬:</translation>
    </message>
</context>
<context>
    <name>Photobucket::DialogWidget</name>
    <message>
        <location filename="../../src/photobucket.cpp" line="275"/>
        <source>All of these words</source>
        <translation>모든 단어 포함</translation>
    </message>
    <message>
        <location filename="../../src/photobucket.cpp" line="276"/>
        <source>Any of these words</source>
        <translation>일부 단어 포함</translation>
    </message>
    <message>
        <location filename="../../src/photobucket.cpp" line="279"/>
        <source>Search for:</source>
        <translation>찾기:</translation>
    </message>
    <message>
        <location filename="../../src/photobucket.cpp" line="293"/>
        <source>Photobucket item</source>
        <translation>Photobucket 항목</translation>
    </message>
    <message>
        <location filename="../../src/photobucket.cpp" line="294"/>
        <source>It can show offending or sexual explicit photos</source>
        <translation>불쾌하거나 성적으로 노골적인 사진이 보여질 수 있습니다.</translation>
    </message>
    <message>
        <location filename="../../src/photobucket.cpp" line="311"/>
        <source>Edit Photobucket item</source>
        <translation>Photobucket 항목 편집</translation>
    </message>
    <message>
        <location filename="../../src/photobucket.cpp" line="317"/>
        <source>Add Photobucket item</source>
        <translation>Photobucket 항목 추가</translation>
    </message>
</context>
<context>
    <name>Photobucket::Item</name>
    <message>
        <location filename="../../src/photobucket.cpp" line="81"/>
        <source>Text:</source>
        <translation>검색어:</translation>
    </message>
    <message>
        <location filename="../../src/photobucket.cpp" line="82"/>
        <source>and</source>
        <translation>그리고</translation>
    </message>
    <message>
        <location filename="../../src/photobucket.cpp" line="83"/>
        <source>or</source>
        <translation>또는</translation>
    </message>
</context>
<context>
    <name>Picasa::DialogWidget</name>
    <message>
        <location filename="../../src/picasa.cpp" line="255"/>
        <source>Search for:</source>
        <translation>찾기:</translation>
    </message>
    <message>
        <location filename="../../src/picasa.cpp" line="278"/>
        <source>Edit Picasa item</source>
        <translation>Picasa 항목 편집</translation>
    </message>
    <message>
        <location filename="../../src/picasa.cpp" line="283"/>
        <source>Add Picasa item</source>
        <translation>Picasa 항목 추가</translation>
    </message>
</context>
<context>
    <name>Picasa::Item</name>
    <message>
        <location filename="../../src/picasa.cpp" line="47"/>
        <source>Text:</source>
        <translation>검색어:</translation>
    </message>
</context>
<context>
    <name>Pikeo::DialogWidget</name>
    <message>
        <location filename="../../src/pikeo.cpp" line="268"/>
        <source>Search for:</source>
        <translation>찾기:</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="273"/>
        <source>Default</source>
        <translation>기본</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="274"/>
        <source>Most viewed</source>
        <translation>가장 많이 본 사진</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="275"/>
        <source>Upload date</source>
        <translation>올린 일시</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="276"/>
        <source>Date taken</source>
        <translation>찍은 일시</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="277"/>
        <source>Group add date</source>
        <translation>그룹 추가 일시</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="278"/>
        <source>Comment date</source>
        <translation>댓글 일시</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="282"/>
        <source>Ascending</source>
        <translation>올림차순</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="284"/>
        <source>Order:</source>
        <translation>정렬:</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="315"/>
        <source>Edit Pikeo item</source>
        <translation>Pikeo 항목 편집</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="322"/>
        <source>Add Pikeo item</source>
        <translation>Pikeo 항목 삭제</translation>
    </message>
</context>
<context>
    <name>Pikeo::Item</name>
    <message>
        <location filename="../../src/pikeo.cpp" line="56"/>
        <source>Tags:</source>
        <translation>태그:</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="57"/>
        <source>Order:</source>
        <translation>정렬:</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="61"/>
        <source>Default</source>
        <translation>기본</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="62"/>
        <source>Most viewed</source>
        <translation>가장 많이 본 사진</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="63"/>
        <source>Upload date</source>
        <translation>올린 일시</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="64"/>
        <source>Date taken</source>
        <translation>찍은 일시</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="65"/>
        <source>Group add date</source>
        <translation>그룹 추가 일시</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="66"/>
        <source>Comment date</source>
        <translation>댓글 일시</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="69"/>
        <source>ascending</source>
        <translation>올림차순</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="69"/>
        <source>descending</source>
        <translation>내림차순</translation>
    </message>
</context>
<context>
    <name>PositionModel</name>
    <message>
        <location filename="../../src/settings.cpp" line="133"/>
        <source>Position</source>
        <translation>위치</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="136"/>
        <source>Picture smaller than screen on the left, greater than screen on the right</source>
        <translation>왼쪽은 화면보다 작은 사진, 오른쪽은 화면보다 큰 사진</translation>
    </message>
</context>
<context>
    <name>QColorDialog</name>
    <message>
        <location filename="../../src/settings.cpp" line="184"/>
        <source>Hu&amp;e:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="185"/>
        <source>&amp;Sat:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="186"/>
        <source>&amp;Val:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="187"/>
        <source>&amp;Red:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="188"/>
        <source>&amp;Green:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="189"/>
        <source>Bl&amp;ue:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="190"/>
        <source>Select Color</source>
        <translation>색상 선택</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="191"/>
        <source>&amp;Basic colors</source>
        <translation>기본 색상(&amp;B)</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="192"/>
        <source>&amp;Custom colors</source>
        <translation>사용자 색상(&amp;C)</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="193"/>
        <source>&amp;Add to Custom Colors</source>
        <translation>사용자 색상에 추가(&amp;A)</translation>
    </message>
</context>
<context>
    <name>QDialogButtonBox</name>
    <message>
        <location filename="../../src/settings.cpp" line="176"/>
        <source>OK</source>
        <translation>확인</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="177"/>
        <source>Cancel</source>
        <translation>취소</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="178"/>
        <source>Reset</source>
        <translation>초기화</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="179"/>
        <source>&amp;Yes</source>
        <translation>예(&amp;Y)</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="180"/>
        <source>&amp;No</source>
        <translation>아니오(&amp;N)</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="181"/>
        <source>Close</source>
        <translation>닫기</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="182"/>
        <source>&amp;Close</source>
        <translation>닫기(&amp;C)</translation>
    </message>
</context>
<context>
    <name>QFileDialog</name>
    <message>
        <location filename="../../src/settings.cpp" line="195"/>
        <source>Directories</source>
        <translation>디렉터리</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="196"/>
        <source>&amp;Open</source>
        <translation>열기(&amp;O)</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="197"/>
        <source>&amp;Save</source>
        <translation>저장(&amp;S)</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="198"/>
        <source>Open</source>
        <translation>열기</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="199"/>
        <source>%1 already exists.
Do you want to replace it?</source>
        <translation>%1 파일이 이미 존재합니다. 교체하시겠습니까?</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="200"/>
        <source>%1
File not found.
Please verify the correct file name was given.</source>
        <translation>%1 파일을 찾을 수 없습니다. 파일 이름이 정확한 지 확인해 주세요.</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="201"/>
        <source>My Computer</source>
        <translation>내 컴퓨터</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="202"/>
        <source>&amp;Rename</source>
        <translation>이름 바꾸기(&amp;R)</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="203"/>
        <source>&amp;Delete</source>
        <translation>삭제(&amp;D)</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="204"/>
        <source>Show &amp;hidden files</source>
        <translation>숨겨진 파일 보이기(&amp;H)</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="205"/>
        <source>Back</source>
        <translation>뒤로</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="206"/>
        <source>Parent Directory</source>
        <translation>상위 디렉터리</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="207"/>
        <source>List View</source>
        <translation>목록 보기</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="208"/>
        <source>Detail View</source>
        <translation>자세히 보기</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="209"/>
        <source>Files of type:</source>
        <translation>파일 형식:</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="210"/>
        <source>Directory:</source>
        <translation>디렉터리:</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="211"/>
        <source>%1
Directory not found.
Please verify the correct directory name was given.</source>
        <translation>%1 디렉터리를 찾을 수 없습니다. 디렉터리 이름이 정확한 지 확인해 주세요.</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="212"/>
        <source>&apos;%1&apos; is write protected.
Do you want to delete it anyway?</source>
        <translation>&apos;%1&apos; 파일은 쓰기 보호되어 있습니다. 그래도 삭제하시겠습니까?</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="213"/>
        <source>Are sure you want to delete &apos;%1&apos;?</source>
        <translation>&apos;%1&apos; 파일 또는 디렉터리를 삭제하시겠습니까?</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="214"/>
        <source>Could not delete directory.</source>
        <translation>디렉터리를 지울 수 없습니다.</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="215"/>
        <source>Recent Places</source>
        <translation>최근</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="216"/>
        <source>Save As</source>
        <translation>다른 이름으로 저장</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="217"/>
        <source>Drive</source>
        <translation>드라이브</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="218"/>
        <source>File</source>
        <translation>파일</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="219"/>
        <source>Unknown</source>
        <translation>알 수 없음</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="220"/>
        <source>Find Directory</source>
        <translation>디렉터리 찾기</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="221"/>
        <source>Show</source>
        <translation>보이기</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="222"/>
        <source>Forward</source>
        <translation>앞으로</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="223"/>
        <source>New Folder</source>
        <translation>새 폴더</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="224"/>
        <source>&amp;New Folder</source>
        <translation>새 폴더(&amp;N)</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="225"/>
        <source>&amp;Choose</source>
        <translation>선택(&amp;C)</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="226"/>
        <source>Remove</source>
        <translation>제거</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="227"/>
        <source>File &amp;name:</source>
        <translation>파일 이름(&amp;N):</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="228"/>
        <source>Look in:</source>
        <translation>탐색:</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="229"/>
        <source>Create New Folder</source>
        <translation>새 폴더 만들기</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../src/utils.cpp" line="76"/>
        <source>All image files</source>
        <translation>모든 사진 파일</translation>
    </message>
    <message>
        <location filename="../../src/utils.cpp" line="80"/>
        <source>files</source>
        <translation>파일</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="31"/>
        <source>Centered</source>
        <translation>중앙</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="34"/>
        <source>Tiled</source>
        <translation>타일</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="37"/>
        <source>Center Tiled</source>
        <translation>가운데 중심으로 타일</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="40"/>
        <source>Centered Maxpect</source>
        <translation>중앙 최대</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="43"/>
        <source>Tiled Maxpect</source>
        <translation>타일 최대</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="46"/>
        <source>Scaled</source>
        <translation>화면 크기에 맞추기</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="49"/>
        <source>Centered Auto Fit</source>
        <translation>자동으로 맞춰진 중앙</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="52"/>
        <source>Scale &amp; Crop</source>
        <translation>확대 &amp; 자르기</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="55"/>
        <source>Symmetrical Tiled</source>
        <translation>대칭된 타일</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="58"/>
        <source>Mirrored Tiled</source>
        <translation>반사된 타일</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="61"/>
        <source>Symmetrical Mirrored Tiled</source>
        <translation>대칭 반사된 타일</translation>
    </message>
</context>
<context>
    <name>QProgressDialog</name>
    <message>
        <location filename="../../src/history.cpp" line="340"/>
        <source>Cancel</source>
        <translation>취소</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../../src/settings.cpp" line="168"/>
        <location filename="../../src/settings.cpp" line="173"/>
        <location filename="../../src/settings.cpp" line="514"/>
        <source>Settings</source>
        <translation>설정</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="239"/>
        <source>Left</source>
        <translation>왼쪽</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="240"/>
        <source>Right</source>
        <translation>오른쪽</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="243"/>
        <source>kBytes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="244"/>
        <source>MBytes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="245"/>
        <source>GBytes</source>
        <translation></translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/settings.cpp" line="248"/>
        <source>day(s)</source>
        <translation>
            <numerusform>일</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/settings.cpp" line="249"/>
        <source>month(s)</source>
        <translation>
            <numerusform>개월</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/settings.cpp" line="299"/>
        <location filename="../../src/settings.cpp" line="524"/>
        <source>second(s)</source>
        <translation>
            <numerusform>초</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/settings.cpp" line="300"/>
        <location filename="../../src/settings.cpp" line="525"/>
        <source>minute(s)</source>
        <translation>
            <numerusform>분</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/settings.cpp" line="301"/>
        <location filename="../../src/settings.cpp" line="526"/>
        <source>hour(s)</source>
        <translation>
            <numerusform>시간</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="453"/>
        <source>Set position</source>
        <translation>위치 설정</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="514"/>
        <source>Changes won&apos;t be applied. Are you sure?</source>
        <translation>변경 사항이 적용되지 않습니다. 계속 하시겠습니까?</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="599"/>
        <source>Clear history</source>
        <translation>기록 삭제</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="599"/>
        <source>Are you sure?</source>
        <translation>계속 하시겠습니까?</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="34"/>
        <source>General options</source>
        <translation>일반 설정</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="42"/>
        <source>Interval:</source>
        <translation>간격:</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="69"/>
        <source>Border:</source>
        <translation>테두리:</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="86"/>
        <location filename="../../ui/settings.ui" line="237"/>
        <source>Position:</source>
        <translation>위치:</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="144"/>
        <source>Main</source>
        <translation>일반</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="153"/>
        <source>Choose in random order</source>
        <translation>무작위 순서로 선택</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="160"/>
        <source>Switch background on play</source>
        <translation>재생 시작할 때 배경 화면 바꾸기</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="167"/>
        <source>Play automatically on application start</source>
        <translation>프로그램이 시작할 때 자동으로 재생</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="174"/>
        <source>Disable splash screen</source>
        <translation>시작 화면 감추기</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="181"/>
        <source>Quit after background change</source>
        <translation>배경 화면 바꾼 후 끝내기</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="188"/>
        <source>Start automatically when system starts</source>
        <translation>컴퓨터를 켤 때 자동으로 시작</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="195"/>
        <source>Only use landscape-oriented photos</source>
        <translation>가로 사진만 사용</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="202"/>
        <source>Rotate images according to EXIF information</source>
        <translation>EXIF 정보에 대응하여 사진 회전</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="211"/>
        <source>View info on photo</source>
        <translation>사진 정보 보기</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="269"/>
        <source>View info in system tray tooltip</source>
        <translation>시스템 알림의 툴팁으로 사진 정보 보기</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="276"/>
        <source>Use full desktop area</source>
        <translation>전체 바탕화면 영역 사용</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="285"/>
        <source>Photo has to be</source>
        <translation>바탕 화면 크기에 대하여</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="296"/>
        <source>independent of</source>
        <translation>상관없는</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="301"/>
        <source>at least 1/2 of</source>
        <translation>최소 1/2</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="306"/>
        <source>at least 3/4 of</source>
        <translation>최소 3/4</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="311"/>
        <source>bigger than</source>
        <translation>더 큰</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="319"/>
        <source>desktop&apos;s size</source>
        <translation>크기의 사진</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="343"/>
        <source>Don&apos;t save locally remote photos if free disk space goes below</source>
        <translation>다음 크기보다 남은 디스크 용량이 작으면 사진을 저장하지 않음:</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="381"/>
        <source>Store images in history for</source>
        <translation>사진 기록을 보관할 기간:</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="398"/>
        <source>Clear</source>
        <translation>삭제</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="630"/>
        <source>Engines</source>
        <translation>모듈</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="750"/>
        <source>Available modules:</source>
        <translation>사용 가능한 모듈:</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="757"/>
        <source>Active modules:</source>
        <translation>사용 중인 모듈:</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="421"/>
        <source>Network</source>
        <translation>네트웍</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="433"/>
        <source>Direct connection</source>
        <translation>직접 연결</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="443"/>
        <source>Proxy connection</source>
        <translation>프록시 연결</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="467"/>
        <source>Use system proxy</source>
        <translation>시스템 프록시 사용</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="477"/>
        <source>Use custom proxy</source>
        <translation>프록시 직접 설정</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="487"/>
        <source>Server:</source>
        <translation>서버:</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="497"/>
        <source>Port:</source>
        <translation>포트:</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="547"/>
        <source>Authentication</source>
        <translation>인증</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="562"/>
        <source>Username:</source>
        <translation>계정:</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="579"/>
        <source>Password:</source>
        <translation>암호:</translation>
    </message>
</context>
<context>
    <name>SmugMug::DialogWidget</name>
    <message>
        <location filename="../../src/smugmug.cpp" line="252"/>
        <source>Search for:</source>
        <translation>찾기:</translation>
    </message>
    <message>
        <location filename="../../src/smugmug.cpp" line="275"/>
        <source>Edit SmugMug item</source>
        <translation>SmugMug 항목 편집</translation>
    </message>
    <message>
        <location filename="../../src/smugmug.cpp" line="280"/>
        <source>Add SmugMug item</source>
        <translation>SmugMug 항목 추가</translation>
    </message>
</context>
<context>
    <name>SmugMug::Item</name>
    <message>
        <location filename="../../src/smugmug.cpp" line="47"/>
        <source>Text:</source>
        <translation>검색어:</translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <location filename="../../src/main.cpp" line="109"/>
        <source>Loading Files module ...</source>
        <translation>파일 모듈 불러오는 중...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="116"/>
        <source>Loading Folders module ...</source>
        <translation>폴더 모듈 불러오는 중...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="123"/>
        <source>Loading Flickr module ...</source>
        <translation>Flickr 모듈 불러오는 중...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="137"/>
        <source>Loading Panoramio module ...</source>
        <translation>Panoramio 모듈 불러오는 중...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="151"/>
        <source>Loading Ipernity module ...</source>
        <translation>Ipernity 모듈 불러오는 중...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="158"/>
        <source>Loading Photobucket module ...</source>
        <translation>Photobucket 모듈 불러오는 중...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="165"/>
        <source>Loading Buzznet module ...</source>
        <translation>Buzznet 모듈 불러오는 중...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="172"/>
        <source>Loading Picasa module ...</source>
        <translation>Picasa 모듈 불러오는 중...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="179"/>
        <source>Loading SmugMug module ...</source>
        <translation>SmugMug 모듈 불러오는 중...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="193"/>
        <source>Loading Google module ...</source>
        <translation>Google 모듈 불러오는 중...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="200"/>
        <source>Loading Vladstudio module ...</source>
        <translation>Vladstudio 모듈 불러오는 중...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="207"/>
        <source>Loading deviantART module ...</source>
        <translation>deviantART 모듈 불러오는 중...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="214"/>
        <source>Loading settings ...</source>
        <translation>설정 불러오는 중...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="221"/>
        <source>Launching Wally ...</source>
        <translation>Wally 시작하는 중...</translation>
    </message>
    <message>
        <location filename="../../src/splash.cpp" line="46"/>
        <source>Author:</source>
        <translation>제작자:</translation>
    </message>
</context>
<context>
    <name>Viewer</name>
    <message>
        <location filename="../../ui/viewer.ui" line="9"/>
        <source>Right-click on photo to show actions</source>
        <translation>옵션을 보려면 항목에 오른클릭을 하세요.</translation>
    </message>
    <message>
        <location filename="../../ui/viewer.ui" line="63"/>
        <source>Fit to window</source>
        <translation>창에 맞추기</translation>
    </message>
    <message>
        <location filename="../../ui/viewer.ui" line="72"/>
        <source>Show full image</source>
        <translation>원래 크기로 보기</translation>
    </message>
    <message>
        <location filename="../../ui/viewer.ui" line="81"/>
        <source>Zoom in</source>
        <translation>확대</translation>
    </message>
    <message>
        <location filename="../../ui/viewer.ui" line="90"/>
        <source>Zoom out</source>
        <translation>축소</translation>
    </message>
    <message>
        <location filename="../../ui/viewer.ui" line="99"/>
        <source>Rotate clockwise</source>
        <translation>오른쪽으로 돌리기</translation>
    </message>
    <message>
        <location filename="../../ui/viewer.ui" line="108"/>
        <source>Rotate c. clockwise</source>
        <translation>왼쪽으로 돌리기</translation>
    </message>
</context>
<context>
    <name>Vladstudio::DialogWidget</name>
    <message>
        <location filename="../../src/vladstudio.cpp" line="325"/>
        <source>All</source>
        <translation>모두</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="326"/>
        <source>Abstract art</source>
        <translation>추상 미술</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="327"/>
        <source>Creatures</source>
        <translation>생물</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="328"/>
        <source>Illustrations</source>
        <translation>삽화</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="329"/>
        <source>Photos</source>
        <translation>사진</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="334"/>
        <source>By ID</source>
        <translation>ID 순</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="335"/>
        <source>By view count</source>
        <translation>많이 본 순</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="340"/>
        <source>Ascending</source>
        <translation>올림차순</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="341"/>
        <source>Descending</source>
        <translation>내림차순</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="344"/>
        <source>Category:</source>
        <translation>범주:</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="345"/>
        <source>Order:</source>
        <translation>정렬:</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="346"/>
        <source>Direction:</source>
        <translation>방향:</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="368"/>
        <source>Edit Vladstudio item</source>
        <translation>Vladstudio 항목 편집</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="375"/>
        <source>Add Vladstudio item</source>
        <translation>Vladstudio 항목 추가</translation>
    </message>
</context>
<context>
    <name>Vladstudio::Item</name>
    <message>
        <location filename="../../src/vladstudio.cpp" line="42"/>
        <source>All categories</source>
        <translation>모든 범주</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="46"/>
        <source>Abstract art</source>
        <translation>추상 미술</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="50"/>
        <source>Creatures</source>
        <translation>생물</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="54"/>
        <source>Illustrations</source>
        <translation>삽화</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="58"/>
        <source>Photos</source>
        <translation>사진</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="89"/>
        <source>by Id</source>
        <translation>ID 순</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="93"/>
        <source>by view count</source>
        <translation>많이 본 순</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="105"/>
        <source>ascending</source>
        <translation>올림차순</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="109"/>
        <source>descending</source>
        <translation>내림차순</translation>
    </message>
</context>
<context>
    <name>Wally::Application</name>
    <message>
        <location filename="../../src/wally.cpp" line="621"/>
        <source>Cancel</source>
        <translation>취소</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="623"/>
        <location filename="../../src/wally.cpp" line="2114"/>
        <source>Play</source>
        <translation>재생</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="625"/>
        <location filename="../../src/wally.cpp" line="2094"/>
        <source>Pause</source>
        <translation>멈춤</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="626"/>
        <source>Next photo</source>
        <translation>다음 사진</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="627"/>
        <source>Save photo...</source>
        <translation>사진 저장...</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="628"/>
        <source>Get EXIF info...</source>
        <translation>EXIF 정보 보기...</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="629"/>
        <source>Settings...</source>
        <translation>설정...</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="630"/>
        <source>Explore source</source>
        <translation>원본 보기</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="631"/>
        <source>About...</source>
        <translation>정보...</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="632"/>
        <source>History...</source>
        <translation>기록...</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="633"/>
        <source>About Qt...</source>
        <translation>Qt에 대하여...</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="634"/>
        <source>Quit</source>
        <translation>끝내기</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="635"/>
        <source>Languages</source>
        <translation>언어</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="637"/>
        <source>English</source>
        <translation>영어</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="638"/>
        <source>Italian</source>
        <translation>이탈리아어</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="639"/>
        <source>Spanish</source>
        <translation>스페인어</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="640"/>
        <source>German</source>
        <translation>독일어</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="641"/>
        <source>French</source>
        <translation>프랑스어</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="642"/>
        <source>Russian</source>
        <translation>러시아어</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="643"/>
        <source>Portuguese (Brazil)</source>
        <translation>포르투갈어</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="644"/>
        <source>Czech</source>
        <translation>체코어</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="645"/>
        <source>Polish</source>
        <translation>폴란드어</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="646"/>
        <source>Chinese (Simplified)</source>
        <translation>중국어 (간체)</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="647"/>
        <source>Chinese (Traditional)</source>
        <translation>중국어 (번체)</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="648"/>
        <source>Catalan</source>
        <translation>카탈로니아어</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="649"/>
        <source>Greek</source>
        <translation>그리스어</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="650"/>
        <source>Korean</source>
        <translation>한국어</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="651"/>
        <source>Hungarian</source>
        <translation>헝가리어</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="652"/>
        <source>Danish</source>
        <translation>덴마크어</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="653"/>
        <source>Swedish</source>
        <translation>스웨덴어</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="654"/>
        <source>Turkish</source>
        <translation>터키어</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="1685"/>
        <source>Wally Error</source>
        <translation>Wally 오류</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="1685"/>
        <source>Active Desktop must be disabled</source>
        <translation>액티브 데스크탑이 비활성화 되어야 합니다.</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="1774"/>
        <location filename="../../src/wally.cpp" line="2065"/>
        <source>by:</source>
        <translation>올린 이:</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="1783"/>
        <source>Location:</source>
        <translation>위치:</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="1791"/>
        <location filename="../../src/wally.cpp" line="2070"/>
        <source>Engine:</source>
        <translation>엔진:</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="2154"/>
        <location filename="../../src/wally.cpp" line="2157"/>
        <source>Save photo</source>
        <translation>사진 저장</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="2155"/>
        <location filename="../../src/wally.cpp" line="2159"/>
        <source>Images (*.png *.xpm *.jpg)</source>
        <translation>사진 (*.png *.xpm *.jpg)</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="2654"/>
        <source>Right-click to show main menu</source>
        <translation>메뉴를 보려면 항목에 오른클릭을 하세요.</translation>
    </message>
</context>
<context>
    <name>Yahoo::DialogWidget</name>
    <message>
        <location filename="../../src/yahoo.cpp" line="268"/>
        <source>All of these words</source>
        <translation>모든 단어 포함</translation>
    </message>
    <message>
        <location filename="../../src/yahoo.cpp" line="269"/>
        <source>Any of these words</source>
        <translation>일부 단어 포함</translation>
    </message>
    <message>
        <location filename="../../src/yahoo.cpp" line="272"/>
        <source>Search for:</source>
        <translation>찾기:</translation>
    </message>
    <message>
        <location filename="../../src/yahoo.cpp" line="277"/>
        <source>Filter content</source>
        <translation>성인물 필터</translation>
    </message>
    <message>
        <location filename="../../src/yahoo.cpp" line="297"/>
        <source>Yahoo! item</source>
        <translation>Yahoo! 항목</translation>
    </message>
    <message>
        <location filename="../../src/yahoo.cpp" line="298"/>
        <source>Unfiltered content can show offending or sexual explicit photos</source>
        <translation>필터되지 않은 내용은 불쾌하거나 성적으로 노골적인 사진이 보일 수 있습니다.</translation>
    </message>
    <message>
        <location filename="../../src/yahoo.cpp" line="309"/>
        <source>Edit Yahoo! item</source>
        <translation>Yahoo! 항목 편집</translation>
    </message>
    <message>
        <location filename="../../src/yahoo.cpp" line="317"/>
        <source>Add Yahoo! item</source>
        <translation>Yahoo! 항목 추가</translation>
    </message>
</context>
<context>
    <name>Yahoo::Item</name>
    <message>
        <location filename="../../src/yahoo.cpp" line="56"/>
        <source>Tags:</source>
        <translation>태그:</translation>
    </message>
    <message>
        <location filename="../../src/yahoo.cpp" line="58"/>
        <source>and</source>
        <translation>그리고</translation>
    </message>
    <message>
        <location filename="../../src/yahoo.cpp" line="58"/>
        <source>or</source>
        <translation>또는</translation>
    </message>
    <message>
        <location filename="../../src/yahoo.cpp" line="61"/>
        <source>content filtered</source>
        <translation>성인물 필터됨</translation>
    </message>
</context>
</TS>
