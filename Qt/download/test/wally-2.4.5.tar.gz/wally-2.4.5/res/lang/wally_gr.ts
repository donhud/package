<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="el_GR">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../../src/about.cpp" line="47"/>
        <source>Compiled with:</source>
        <translation>Προσαρμογή με:</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="49"/>
        <source>EXIF library:</source>
        <translation>Βιβλιοθήκη EXIF:</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="52"/>
        <source>present</source>
        <translation>υπάρχει</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="54"/>
        <source>not present</source>
        <translation>δεν υπάρχει</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="58"/>
        <source>English</source>
        <translation>Αγγλικά</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="60"/>
        <source>Italian</source>
        <translation>Ιταλικά</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="62"/>
        <source>Russian</source>
        <translation>Ρωσικά</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="64"/>
        <source>Spanish</source>
        <translation>Ισπανικά</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="66"/>
        <source>Portuguese (Brazil)</source>
        <translation>Πορτογαλικά(Βραζιλίας)</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="68"/>
        <source>German</source>
        <translation>Γερμανικά</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="70"/>
        <source>French</source>
        <translation>Γαλλικά</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="72"/>
        <source>Czech</source>
        <translation>Τσέχικα</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="74"/>
        <source>Chinese (Simplified)</source>
        <translation>Κινέζικα (απλοποιημένα)</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="76"/>
        <source>Chinese (Traditional)</source>
        <translation>Κινέζικα (παραδοσιακά)</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="78"/>
        <source>Polish</source>
        <translation>Πολωνικά</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="80"/>
        <source>Catalan</source>
        <translation>Καταλανικά</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="82"/>
        <source>Greek</source>
        <translation>Ελληνικά</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="84"/>
        <source>Korean</source>
        <translation>Κορεατικά</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="86"/>
        <source>Hungarian</source>
        <translation>Ουγγρικά</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="88"/>
        <source>Danish</source>
        <translation>Δανέζικα</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="90"/>
        <source>Swedish</source>
        <translation>Σουηδικά</translation>
    </message>
    <message>
        <location filename="../../src/about.cpp" line="92"/>
        <source>Turkish</source>
        <translation>Τουρκικά</translation>
    </message>
    <message>
        <location filename="../../ui/about.ui" line="6"/>
        <source>About Wally</source>
        <translation>Περί Wally</translation>
    </message>
    <message>
        <location filename="../../ui/about.ui" line="65"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;/head&gt;&lt;body&gt;&lt;font size=&quot;+1&quot;&gt;Qt4 desktop wallpaper changer&lt;br /&gt;Author: Antonio Di Monaco (a.k.a. &lt;i&gt;Sin(x) &apos;76&lt;/i&gt;)&lt;br /&gt;I&apos;d like to thank Vincent Willem van Gogh for the logo :)&lt;br /&gt;&lt;br /&gt;Web site: &lt;a href=&quot;http://www.becrux.com&quot;&gt;http://www.becrux.com&lt;/a&gt;&lt;br /&gt;You can contact me at &lt;a href=&quot;mailto:tony@becrux.com?subject=About Wally&quot;&gt;tony@becrux.com&lt;/font&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;/head&gt;&lt;body&gt;&lt;font size=&quot;+1&quot;&gt;Qt4 εναλλαγή ταπετσαρίας επιφάνειας εργασίας&lt;br /&gt;Δημιουργός: Antonio Di Monaco (a.k.a. &lt;i&gt;Sin(x) &apos;76&lt;/i&gt;)&lt;br /&gt;Ευχαριστίες στον Vincent Willem van Gogh για το logo :)&lt;br /&gt;&lt;br /&gt;Ιστοσελίδα: &lt;a href=&quot;http://www.becrux.com&quot;&gt;http://www.becrux.com&lt;/a&gt;&lt;br /&gt;Μπορείτε να επικοινωνήσετε μαζί μου στο&lt;a href=&quot;mailto:tony@becrux.com?θέμα=Περί Wally&quot;&gt;tony@becrux.com&lt;/font&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../ui/about.ui" line="94"/>
        <source>Details &gt;&gt;</source>
        <translation>Λεπτομέρειες &gt;&gt;</translation>
    </message>
    <message>
        <location filename="../../ui/about.ui" line="104"/>
        <source>Close</source>
        <translation>Κλείσιμο</translation>
    </message>
    <message>
        <location filename="../../ui/about.ui" line="152"/>
        <source>Extension</source>
        <translation>Επέκταση</translation>
    </message>
    <message>
        <location filename="../../ui/about.ui" line="157"/>
        <source>Description</source>
        <translation>Περιγραφή</translation>
    </message>
    <message>
        <location filename="../../ui/about.ui" line="165"/>
        <source>Supported image formats:</source>
        <translation>Υποστηριζόμενοι τύποι εικόνας:</translation>
    </message>
    <message>
        <location filename="../../ui/about.ui" line="172"/>
        <source>Additional info:</source>
        <translation>Πρόσθετες πληροφορίες:</translation>
    </message>
    <message>
        <location filename="../../ui/about.ui" line="244"/>
        <source>Language</source>
        <translation>Γλώσσα</translation>
    </message>
    <message>
        <location filename="../../ui/about.ui" line="249"/>
        <source>Translator</source>
        <translation>Μεταφραστής</translation>
    </message>
    <message>
        <location filename="../../ui/about.ui" line="257"/>
        <source>Translations:</source>
        <translation>Μεταφράσεις:</translation>
    </message>
</context>
<context>
    <name>Bing::DialogWidget</name>
    <message>
        <location filename="../../src/bing.cpp" line="304"/>
        <source>All of these words</source>
        <translation>&apos;Ολες οι λέξεις</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="305"/>
        <source>Any of these words</source>
        <translation>Όποια λέξη</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="308"/>
        <source>Search for:</source>
        <translation>Αναζήτηση γιά:</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="314"/>
        <source>Strict</source>
        <translation>Ακριβώς</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="315"/>
        <source>Moderate</source>
        <translation>Μέτρια</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="316"/>
        <source>Off</source>
        <translation>Εκτός</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="319"/>
        <source>Adult filter:</source>
        <translation>Φίλτρο ενηλίκων:</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="342"/>
        <source>Bing item</source>
        <translation>Αντικείμενο Bing</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="343"/>
        <source>Unfiltered content can show offending or sexual explicit photos</source>
        <translation>Αφιλτράριστο περιεχόμενο μπορεί να δείξε προσβλητικό ή σκληρό πορνογραφικό θέαμα</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="354"/>
        <source>Edit Bing item</source>
        <translation>Σύνταξη αντικείμενου Bing</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="361"/>
        <source>Add Bing item</source>
        <translation>Πρόσθεση αντικειμένου Bing</translation>
    </message>
</context>
<context>
    <name>Bing::Item</name>
    <message>
        <location filename="../../src/bing.cpp" line="56"/>
        <source>Tags:</source>
        <translation>Ετικέτες:</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="58"/>
        <source>and</source>
        <translation>καί</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="58"/>
        <source>or</source>
        <translation>ή</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="59"/>
        <source>Adult filter:</source>
        <translation>Φίλτρο ενηλίκων:</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="64"/>
        <source>Off</source>
        <translation>Εκτός</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="68"/>
        <source>Moderate</source>
        <translation>Μέτρια</translation>
    </message>
    <message>
        <location filename="../../src/bing.cpp" line="73"/>
        <source>Strict</source>
        <translation>Ακριβώς</translation>
    </message>
</context>
<context>
    <name>Buzznet::DialogWidget</name>
    <message>
        <location filename="../../src/buzznet.cpp" line="225"/>
        <source>Search for:</source>
        <translation>Αναζήτηση γιά:</translation>
    </message>
    <message>
        <location filename="../../src/buzznet.cpp" line="248"/>
        <source>Edit Buzznet item</source>
        <translation>Σύνταξη  αντικειμένου Buzznet</translation>
    </message>
    <message>
        <location filename="../../src/buzznet.cpp" line="253"/>
        <source>Add Buzznet item</source>
        <translation>Πρόσθεση αντικειμένου Buzznet</translation>
    </message>
</context>
<context>
    <name>Buzznet::Item</name>
    <message>
        <location filename="../../src/buzznet.cpp" line="42"/>
        <source>Tag:</source>
        <translation>Ετικέτα:</translation>
    </message>
</context>
<context>
    <name>DeviantArt::DialogWidget</name>
    <message>
        <location filename="../../src/deviantart.cpp" line="247"/>
        <source>Search for:</source>
        <translation>Αναζήτηση γιά:</translation>
    </message>
    <message>
        <location filename="../../src/deviantart.cpp" line="252"/>
        <source>Strict</source>
        <translation>Ακριβώς</translation>
    </message>
    <message>
        <location filename="../../src/deviantart.cpp" line="253"/>
        <source>Off</source>
        <translation>Εκτός</translation>
    </message>
    <message>
        <location filename="../../src/deviantart.cpp" line="256"/>
        <source>Adult filter:</source>
        <translation>Φίλτρο ενηλίκων:</translation>
    </message>
    <message>
        <location filename="../../src/deviantart.cpp" line="277"/>
        <source>deviantART item</source>
        <translation>Πρόσθεση αντικειμένου deviantART</translation>
    </message>
    <message>
        <location filename="../../src/deviantart.cpp" line="278"/>
        <source>Unfiltered content can show offending or sexual explicit photos</source>
        <translation>Αφιλτράριστο περιεχόμενο μπορεί να δείξε προσβλητικό ή σκληρό πορνογραφικό θέαμα</translation>
    </message>
    <message>
        <location filename="../../src/deviantart.cpp" line="289"/>
        <source>Edit deviantART item</source>
        <translation>Επεξεργασία αντικείμενου deviantART</translation>
    </message>
    <message>
        <location filename="../../src/deviantart.cpp" line="295"/>
        <source>Add deviantART item</source>
        <translation>Προσθήκη αντικείμενου deviantART</translation>
    </message>
</context>
<context>
    <name>DeviantArt::Item</name>
    <message>
        <location filename="../../src/deviantart.cpp" line="43"/>
        <source>Tag:</source>
        <translation>Ετικέτα:</translation>
    </message>
    <message>
        <location filename="../../src/deviantart.cpp" line="44"/>
        <source>Adult filter:</source>
        <translation>Φίλτρο ενηλίκων:</translation>
    </message>
    <message>
        <location filename="../../src/deviantart.cpp" line="49"/>
        <source>Off</source>
        <translation>Εκτός</translation>
    </message>
    <message>
        <location filename="../../src/deviantart.cpp" line="54"/>
        <source>Strict</source>
        <translation>Ακριβώς</translation>
    </message>
</context>
<context>
    <name>Exif::InfoDialog</name>
    <message>
        <location filename="../../src/exif.cpp" line="260"/>
        <source>EXIF information</source>
        <translation>Πληροφορίες EXIF</translation>
    </message>
    <message>
        <location filename="../../src/exif.cpp" line="274"/>
        <source>Tag</source>
        <translation>Ετικέτα</translation>
    </message>
    <message>
        <location filename="../../src/exif.cpp" line="275"/>
        <source>Value</source>
        <translation>Τιμή</translation>
    </message>
    <message>
        <location filename="../../src/exif.cpp" line="298"/>
        <source>No EXIF information available</source>
        <translation>Δεν υπάρχουν πληροφορίες EXIF</translation>
    </message>
</context>
<context>
    <name>Files::Core</name>
    <message>
        <location filename="../../src/files.cpp" line="145"/>
        <source>Loading folder...</source>
        <translation>Φόρτωση φακέλου...</translation>
    </message>
</context>
<context>
    <name>Files::LabelPreview</name>
    <message>
        <location filename="../../src/files.cpp" line="261"/>
        <source>No preview available</source>
        <translation>Δεν διατίθεται προεπισκόπηση</translation>
    </message>
</context>
<context>
    <name>Files::SettingsWidget</name>
    <message>
        <location filename="../../src/files.cpp" line="281"/>
        <location filename="../../src/files.cpp" line="334"/>
        <source>Select a photo</source>
        <translation>Επιλέγξτε φωτογραφία</translation>
    </message>
    <message>
        <location filename="../../src/files.cpp" line="297"/>
        <location filename="../../src/files.cpp" line="302"/>
        <source>Select a folder</source>
        <translation>Επιλέγξτε φάκελο</translation>
    </message>
</context>
<context>
    <name>FilesSettingsWidget</name>
    <message>
        <location filename="../../ui/files.ui" line="15"/>
        <source>Photos</source>
        <translation>Φωτογραφίες</translation>
    </message>
    <message>
        <location filename="../../ui/files.ui" line="39"/>
        <source>Add a photo</source>
        <translation>Προσθέστε μία φωτογραφία</translation>
    </message>
    <message>
        <location filename="../../ui/files.ui" line="59"/>
        <source>Add photos in folder</source>
        <translation>Προσθέστε φωτογραφίες στο φάκελο</translation>
    </message>
    <message>
        <location filename="../../ui/files.ui" line="82"/>
        <source>Delete photo</source>
        <translation>Διαγραφή φωτογραφίας</translation>
    </message>
    <message>
        <location filename="../../ui/files.ui" line="118"/>
        <source>Move photo up</source>
        <translation>Μετακίνηση φωτογραφίας πάνω</translation>
    </message>
    <message>
        <location filename="../../ui/files.ui" line="141"/>
        <source>Move photo down</source>
        <translation>Μετακίνηση φωτογραφίας κάτω</translation>
    </message>
</context>
<context>
    <name>Flickr::DialogWidget</name>
    <message>
        <location filename="../../src/flickr.cpp" line="395"/>
        <source>All of these words</source>
        <translation>Όλες οι λέξεις</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="396"/>
        <source>Any of these words</source>
        <translation>Όποια λέξη</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="400"/>
        <source>Search for:</source>
        <translation>Αναζήτηση γιά:</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="404"/>
        <source>Full text</source>
        <translation>Πλήρες κείμενο</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="405"/>
        <source>Tags only</source>
        <translation>Μόνο ετικέτες</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="413"/>
        <source>Largest</source>
        <translation>Μεγαλύτερο</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="414"/>
        <source>Original</source>
        <translation>Πρωτότυπο</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="415"/>
        <source>Large</source>
        <translation>Μεγάλο</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="416"/>
        <source>Medium</source>
        <translation>Μεσαίο</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="417"/>
        <source>Small</source>
        <translation>Μικρό</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="418"/>
        <source>Thumbnail</source>
        <translation>Μικρογραφίες</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="419"/>
        <source>Square</source>
        <translation>Τετράγωνο</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="420"/>
        <source>Smallest</source>
        <translation>Μικρότερο</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="425"/>
        <source>Interestingness desc</source>
        <translation>Κατά ενδιαφέρον φθίν</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="426"/>
        <source>Relevance</source>
        <translation>Αρμοδιότης</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="427"/>
        <source>Date posted desc</source>
        <translation>Ημερομηνία ανάρτησης φθιν</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="428"/>
        <source>Date taken desc</source>
        <translation>Ημερομηνία λήψης φθιν</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="429"/>
        <source>Interestingness asc</source>
        <translation>Κατά ενδιαφέρον αύξ</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="430"/>
        <source>Date posted asc</source>
        <translation>Ημερομηνία ανάρτησης αύξ</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="431"/>
        <source>Date taken asc</source>
        <translation>Ημερομηνία λήψης αύξ</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="434"/>
        <source>Size:</source>
        <translation>Μέγεθος:</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="436"/>
        <source>Order:</source>
        <translation>Κατάταξη:</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="478"/>
        <source>Edit Flickr item</source>
        <translation>Σύνταξη αντικειμένου Flickr</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="496"/>
        <source>Add Flickr item</source>
        <translation>Προσθήκη αντικειμένου Flickr</translation>
    </message>
</context>
<context>
    <name>Flickr::Item</name>
    <message>
        <location filename="../../src/flickr.cpp" line="58"/>
        <source>Text:</source>
        <translation>Κείμενο:</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="60"/>
        <source>Tags:</source>
        <translation>Ετικέτες:</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="61"/>
        <source>and</source>
        <translation>καί</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="62"/>
        <source>or</source>
        <translation>ή</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="66"/>
        <source>Size:</source>
        <translation>Μέγεθος:</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="69"/>
        <source>Largest</source>
        <translation>Μέγιστο</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="70"/>
        <source>Original</source>
        <translation>Αρχικό</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="71"/>
        <source>Large</source>
        <translation>Μεγάλο</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="72"/>
        <source>Medium</source>
        <translation>Μεσαίο</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="73"/>
        <source>Small</source>
        <translation>Μικρό</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="74"/>
        <source>Thumbnail</source>
        <translation>Μικρογραφίες</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="75"/>
        <source>Square</source>
        <translation>Τετράγωνο</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="76"/>
        <source>Smallest</source>
        <translation>Ελάχιστο</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="79"/>
        <source>Order:</source>
        <translation>Κατάταξη:</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="82"/>
        <source>Interestingness desc</source>
        <translation>Κατά ενδιαφέρον φθίν</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="83"/>
        <source>Relevance</source>
        <translation>Σχετικότης</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="84"/>
        <source>Date posted desc</source>
        <translation>Ημερομηνία ανάρτησης φθιν</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="85"/>
        <source>Date taken desc</source>
        <translation>Ημερομηνία λήψης φθιν</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="86"/>
        <source>Interestingness asc</source>
        <translation>Κατά ενδιαφέρον αύξ</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="87"/>
        <source>Date posted asc</source>
        <translation>Ημερομηνία ανάρτησης αύξ</translation>
    </message>
    <message>
        <location filename="../../src/flickr.cpp" line="88"/>
        <source>Date taken asc</source>
        <translation>Ημερομηνία λήψης αύξ</translation>
    </message>
</context>
<context>
    <name>Folders::DialogWidget</name>
    <message>
        <location filename="../../src/folders.cpp" line="447"/>
        <location filename="../../src/folders.cpp" line="456"/>
        <source>Local</source>
        <translation>Τοπικό</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="448"/>
        <location filename="../../src/folders.cpp" line="479"/>
        <source>Remote</source>
        <translation>Απομακρυσμένο</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="463"/>
        <source>Include subfolders</source>
        <translation>Συμπεριλαμβάνει υποφακέλους</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="469"/>
        <source>Folder:</source>
        <translation>Φάκελος:</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="488"/>
        <source>Passive</source>
        <translation>Παθητικό</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="489"/>
        <source>Active</source>
        <translation>Ενεργό</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="501"/>
        <source>Server:</source>
        <translation>Διακομιστής:</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="503"/>
        <source>Port:</source>
        <translation>Θύρα:</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="505"/>
        <source>Transfer mode:</source>
        <translation>Λειτουργία μεταφοράς:</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="507"/>
        <source>Username:</source>
        <translation>Όνομα χρήστη:</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="509"/>
        <source>Password:</source>
        <translation>Κωδικός πρόσβασης:</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="511"/>
        <source>Path:</source>
        <translation>Διαδρομή:</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="534"/>
        <location filename="../../src/folders.cpp" line="539"/>
        <source>Select a folder</source>
        <translation>Επιλέγξτε φάκελο</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="588"/>
        <source>Edit folder</source>
        <translation>Σύνταξη φακέλου</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="614"/>
        <source>Add folder</source>
        <translation>Πρόσθεση φακέλου</translation>
    </message>
</context>
<context>
    <name>Folders::LocalItem</name>
    <message>
        <location filename="../../src/folders.cpp" line="149"/>
        <source>(with subfolders)</source>
        <translation>(με υποφακέλους)</translation>
    </message>
</context>
<context>
    <name>Folders::RemoteItem</name>
    <message>
        <location filename="../../src/folders.cpp" line="253"/>
        <source>Transfer mode:</source>
        <translation>Λειτουργία μεταφοράς:</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="254"/>
        <source>passive</source>
        <translation>Παθητική</translation>
    </message>
    <message>
        <location filename="../../src/folders.cpp" line="254"/>
        <source>active</source>
        <translation>Ενεργή</translation>
    </message>
</context>
<context>
    <name>FoldersSettingsWidget</name>
    <message>
        <location filename="../../ui/folders.ui" line="15"/>
        <source>Folders</source>
        <translation>Φάκελοι</translation>
    </message>
    <message>
        <location filename="../../ui/folders.ui" line="26"/>
        <source>Add a folder</source>
        <translation>Πρόσθεση φακέλου</translation>
    </message>
    <message>
        <location filename="../../ui/folders.ui" line="49"/>
        <source>Delete folder</source>
        <translation>Διαγραφή φακέλου</translation>
    </message>
</context>
<context>
    <name>Google::DialogWidget</name>
    <message>
        <location filename="../../src/google.cpp" line="347"/>
        <source>Search for:</source>
        <translation>Αναζήτηση γιά:</translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="352"/>
        <source>Strict</source>
        <translation>Ακριβώς</translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="353"/>
        <source>Moderate</source>
        <translation>Μέτρια</translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="354"/>
        <source>Off</source>
        <translation>Εκτός</translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="357"/>
        <source>Adult filter:</source>
        <translation>Φίλτρο ενηλίκων:</translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="378"/>
        <source>Google item</source>
        <translation>Αντικείμενο Google</translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="379"/>
        <source>Unfiltered content can show offending or sexual explicit photos</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="390"/>
        <source>Edit Google item</source>
        <translation>Επεξεργασία αντικείμενου Google</translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="396"/>
        <source>Add Google item</source>
        <translation>Προσθέστε αντικείμενο Google</translation>
    </message>
</context>
<context>
    <name>Google::Item</name>
    <message>
        <location filename="../../src/google.cpp" line="55"/>
        <source>Text:</source>
        <translation>Κείμενο:</translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="56"/>
        <source>Adult filter:</source>
        <translation>Φίλτρο ενηλίκων:</translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="61"/>
        <source>Off</source>
        <translation>Εκτός</translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="65"/>
        <source>Moderate</source>
        <translation>Μέτρια</translation>
    </message>
    <message>
        <location filename="../../src/google.cpp" line="70"/>
        <source>Strict</source>
        <translation>Ακριβώς</translation>
    </message>
</context>
<context>
    <name>Gui::ColorButton</name>
    <message>
        <location filename="../../src/gui.cpp" line="132"/>
        <location filename="../../src/gui.cpp" line="140"/>
        <source>Auto</source>
        <translation>Αυτόματα</translation>
    </message>
</context>
<context>
    <name>History::Dialog</name>
    <message>
        <location filename="../../src/history.cpp" line="364"/>
        <source>Right-click on items to show options</source>
        <translation>Κάντε δεξί κλικ στα στοιχεία για να δείτε τις επιλογές</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="395"/>
        <location filename="../../src/history.cpp" line="596"/>
        <location filename="../../src/history.cpp" line="613"/>
        <source>History</source>
        <translation>Ιστορικό</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="440"/>
        <source>Please wait...</source>
        <translation>Παρακαλώ περιμένετε...</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="441"/>
        <source>Downloading photo...</source>
        <translation>Λήψεις φωτογραφιών...</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="442"/>
        <source>Abort</source>
        <translation>Ματαίωση</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="454"/>
        <location filename="../../src/history.cpp" line="458"/>
        <source>Save photo</source>
        <translation>Αποθήκευση φωτογραφιών</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="456"/>
        <location filename="../../src/history.cpp" line="461"/>
        <source>Images (*.png *.xpm *.jpg)</source>
        <translation>Εικόνες (*.png *.xpm *.jpg)</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="596"/>
        <source>Photo has been saved</source>
        <translation>Φωτογραφία εχει αποθηκευτεί</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="613"/>
        <source>There was an error during download</source>
        <translation>Παρουσιάστηκε σφάλμα κατά τη λήψη</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="663"/>
        <source>View photo...</source>
        <translation>Προβολή φωτογραφίας...</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="667"/>
        <source>Get EXIF info...</source>
        <translation>Λάβετε EXIF πληροφορίες ...</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="671"/>
        <source>Save photo...</source>
        <translation>Αποθήκευση φωτογραφιών...</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="675"/>
        <source>Set as background</source>
        <translation>Ορισμός ως φόντο</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="679"/>
        <source>Explore image source</source>
        <translation>Εξερευνήστε την προέλευση εικόνας</translation>
    </message>
</context>
<context>
    <name>History::EngineQueryModel</name>
    <message>
        <location filename="../../src/history.cpp" line="70"/>
        <source>All</source>
        <translation>Όλα</translation>
    </message>
</context>
<context>
    <name>History::PhotosQueryModel</name>
    <message>
        <location filename="../../src/history.cpp" line="238"/>
        <source>(no title)</source>
        <translation>(χωρίς τίτλο)</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="240"/>
        <source>by:</source>
        <translation>υπό:</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="241"/>
        <source>(no author)</source>
        <translation>(χωρίς δημιουργό)</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="243"/>
        <source>Date:</source>
        <translation>Ημερομηνία:</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="245"/>
        <source>Location:</source>
        <translation>Τοποθεσία:</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="246"/>
        <source>unknown</source>
        <translation>άγνωστο</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="248"/>
        <source>Size:</source>
        <translation>Μέγεθος:</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="250"/>
        <source>Image size:</source>
        <translation>Μέγεθος εικόνας:</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="252"/>
        <source>Engine:</source>
        <translation>Μηχανή:</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="253"/>
        <source>EXIF:</source>
        <translation>EXIF:</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="253"/>
        <source>No</source>
        <translation>Όχι</translation>
    </message>
    <message>
        <location filename="../../src/history.cpp" line="253"/>
        <source>Yes</source>
        <translation>Ναί</translation>
    </message>
</context>
<context>
    <name>History::TagsQueryModel</name>
    <message>
        <location filename="../../src/history.cpp" line="99"/>
        <source>All</source>
        <translation>Όλα</translation>
    </message>
</context>
<context>
    <name>HttpEngine::SettingsWidget</name>
    <message>
        <location filename="../../src/httpengine.cpp" line="656"/>
        <location filename="../../src/httpengine.cpp" line="661"/>
        <source>Select a folder</source>
        <translation>Επιλέγξτε ένα φάκελο</translation>
    </message>
</context>
<context>
    <name>HttpSettingsWidget</name>
    <message>
        <location filename="../../ui/http.ui" line="12"/>
        <source>Photo sets</source>
        <translation>Συλλογή φωτογραφιών</translation>
    </message>
    <message>
        <location filename="../../ui/http.ui" line="20"/>
        <source>Add a photo set</source>
        <translation>Προσθέστε μία συλλογή φωτογραφιών</translation>
    </message>
    <message>
        <location filename="../../ui/http.ui" line="43"/>
        <source>Delete photo set</source>
        <translation>Διαγράψτε τη συλλογή φωτογραφιών</translation>
    </message>
    <message>
        <location filename="../../ui/http.ui" line="97"/>
        <source>Options</source>
        <translation>Επιλογές</translation>
    </message>
    <message>
        <location filename="../../ui/http.ui" line="103"/>
        <source>Save photos</source>
        <translation>Αποθήκευση φωτογραφιών</translation>
    </message>
</context>
<context>
    <name>Ipernity::DialogWidget</name>
    <message>
        <location filename="../../src/ipernity.cpp" line="284"/>
        <source>All of these words</source>
        <translation>Όλες οι λέξεις</translation>
    </message>
    <message>
        <location filename="../../src/ipernity.cpp" line="285"/>
        <source>Any of these words</source>
        <translation>Όποια λέξη</translation>
    </message>
    <message>
        <location filename="../../src/ipernity.cpp" line="288"/>
        <source>Search for:</source>
        <translation>Αναζήτηση γιά:</translation>
    </message>
    <message>
        <location filename="../../src/ipernity.cpp" line="292"/>
        <source>Full text</source>
        <translation>Πλήρες κείμενο</translation>
    </message>
    <message>
        <location filename="../../src/ipernity.cpp" line="293"/>
        <source>Tags only</source>
        <translation>Μόνο ετικέτες</translation>
    </message>
    <message>
        <location filename="../../src/ipernity.cpp" line="309"/>
        <source>Ipernity item</source>
        <translation>Προσθήκη αντικείμενου Ipernity</translation>
    </message>
    <message>
        <location filename="../../src/ipernity.cpp" line="310"/>
        <source>It can show offending or sexual explicit photos</source>
        <translation>Αφιλτράριστο περιεχόμενο μπορεί να δείξει προσβλητικό ή σκληρό πορνογραφικό θέαμα</translation>
    </message>
    <message>
        <location filename="../../src/ipernity.cpp" line="331"/>
        <source>Edit Ipernity item</source>
        <translation>Επεξεργασία αντικείμενου Ipernity</translation>
    </message>
    <message>
        <location filename="../../src/ipernity.cpp" line="347"/>
        <source>Add Ipernity item</source>
        <translation>Προσθήκη αντικείμενου Ipernity</translation>
    </message>
</context>
<context>
    <name>Ipernity::Item</name>
    <message>
        <location filename="../../src/ipernity.cpp" line="57"/>
        <source>Text:</source>
        <translation>Κείμενο:</translation>
    </message>
    <message>
        <location filename="../../src/ipernity.cpp" line="58"/>
        <location filename="../../src/ipernity.cpp" line="63"/>
        <source>and</source>
        <translation>καί</translation>
    </message>
    <message>
        <location filename="../../src/ipernity.cpp" line="59"/>
        <location filename="../../src/ipernity.cpp" line="64"/>
        <source>or</source>
        <translation>ή</translation>
    </message>
    <message>
        <location filename="../../src/ipernity.cpp" line="66"/>
        <source>Tags:</source>
        <translation>Ετικέτες:</translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../../src/main.cpp" line="65"/>
        <source>Error</source>
        <translation>Σφάλμα</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="68"/>
        <source>is already running</source>
        <translation>εκτελείται ήδη</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="77"/>
        <source>Disclaimer</source>
        <translation>Άρνηση ευθύνης</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="78"/>
        <source>&lt;b&gt;The Author takes no responsibility over the content that Wally downloads from photo sharing web sites.&lt;br&gt;The Author is in no way responsible for any such content.&lt;/b&gt;&lt;br&gt;&lt;br&gt;If this is a problem for you, please use only local engines like &quot;Files&quot; or local &quot;Folders&quot;.&lt;br&gt;Otherwise, please select &lt;b&gt;&quot;No&quot;&lt;/b&gt; to exit Wally, or use it &lt;b&gt;at your own risk.&lt;/b&gt;&lt;br&gt;&lt;br&gt;(If you proceed, this message will appear only once)&lt;br&gt;&lt;br&gt;Do you accept the above condition?</source>
        <translation>&lt;b&gt; Ο Δημιουργός δεν αναλαμβάνει καμία ευθύνη για το περιεχόμενο που το Wally κατεβάζει από τοποθεσίες κοινής χρήσης φωτογραφιών.&lt;br&gt; ο Δημιουργός δεν φέρει καμία ευθύνη για οποιοδήποτε τέτοιο περιεχόμενο.&lt;/b&gt;&lt;br&gt;&lt;br&gt;Εάν αυτό είναι πρόβλημα για εσάς, παρακαλούμε να χρησιμοποιήσετε μόνο τοπικές μηχανές όπως &quot;Αρχεία&quot; ή τοπικοί &quot;Φάκελοι&quot;. &lt;br&gt;Διαφορετικά, παρακαλώ επιλέξτε &lt;b&gt; &quot;Όχι&quot; &lt;/b&gt; για να βγείτε απο το  Wally, ή να το χρησιμοποιήσετε &lt;b&gt; με δική σας ευθύνη. &lt;/b&gt;&lt;br&gt;&lt;br&gt; (Αν συνεχίσετε, αυτό το μήνυμα θα εμφανιστεί μόνο μία φορά) &lt;br&gt;&lt;br&gt;Δέχεστε την παραπάνω κατάσταση;</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="66"/>
        <source>Another instance of</source>
        <translation>Μια άλλη παρουσία αυτού του προγράμματος</translation>
    </message>
</context>
<context>
    <name>Map::View</name>
    <message>
        <location filename="../../src/mapviewer.cpp" line="387"/>
        <source>Drag to select. Right-click to zoom</source>
        <translation>Σύρετε για να επιλέξετε. Κάντε δεξί κλικ για μεγέθυνση</translation>
    </message>
    <message>
        <location filename="../../src/mapviewer.cpp" line="395"/>
        <source>Zoom %1x</source>
        <translation>Μεγένθυση %1x</translation>
    </message>
</context>
<context>
    <name>Map::Viewer</name>
    <message>
        <location filename="../../src/mapviewer.cpp" line="434"/>
        <source>Map viewer</source>
        <translation>Προβολή χάρτη</translation>
    </message>
</context>
<context>
    <name>Panoramio::DialogWidget</name>
    <message>
        <location filename="../../src/panoramio.cpp" line="322"/>
        <source>Select on map</source>
        <translation>Επιλέγξτε στον χάρτη</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="328"/>
        <source>Longitude (min):</source>
        <translation>Γεωγρ.Μήκος(ελαχ):</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="330"/>
        <source>Longitude (max):</source>
        <translation>Γεωγρ.Μήκος(μεγ):</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="332"/>
        <source>Latitude (min):</source>
        <translation>Γεωγρ.Πλάτος(ελαχ):</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="334"/>
        <source>Latitude (max):</source>
        <translation>Γεωγρ.Πλάτος(μεγ):</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="352"/>
        <source>Popularity</source>
        <translation>Δημοτικότητα</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="353"/>
        <source>Upload date</source>
        <translation>Ημερομηνία ανεβάσματος</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="358"/>
        <source>Original</source>
        <translation>Αρχικό</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="359"/>
        <source>Medium</source>
        <translation>Μεσαίο</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="360"/>
        <source>Small</source>
        <translation>Μικρό</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="361"/>
        <source>Thumbnail</source>
        <translation>Μικρογραφίες</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="362"/>
        <source>Square</source>
        <translation>Τετράγωνο</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="363"/>
        <source>Mini square</source>
        <translation>Μίνι τετράγωνο</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="366"/>
        <source>Order:</source>
        <translation>Κατάταξη:</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="367"/>
        <source>Size:</source>
        <translation>Μέγεθος:</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="414"/>
        <source>Edit Panoramio item</source>
        <translation>Επεξεργασία αντικείμενου Panoramio</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="427"/>
        <source>Add Panoramio item</source>
        <translation>Προσθήκη αντικείμενου Panoramio</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="435"/>
        <source>Error</source>
        <translation>Σφάλμα</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="435"/>
        <source>Coordinates must be different</source>
        <translation>Συντεταγμένες πρέπει να είναι διαφορετικές</translation>
    </message>
</context>
<context>
    <name>Panoramio::Item</name>
    <message>
        <location filename="../../src/panoramio.cpp" line="185"/>
        <source>lat:</source>
        <translation>πλατ:</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="186"/>
        <source>lon:</source>
        <translation>μήκ:</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="284"/>
        <source>Original</source>
        <translation>Αρχικό</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="285"/>
        <source>Medium</source>
        <translation>Μεσαίο</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="286"/>
        <source>Small</source>
        <translation>Μικρό</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="287"/>
        <source>Thumbnail</source>
        <translation>Μικρογραφίες</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="288"/>
        <source>Square</source>
        <translation>Τετράγωνο</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="289"/>
        <source>Mini square</source>
        <translation>Μίνι τετράγωνο</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="294"/>
        <source>Popularity</source>
        <translation>Δημοτικότητα</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="295"/>
        <source>Upload date</source>
        <translation>Ημερομηνία ανεβάσματος</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="298"/>
        <source>Longitude:</source>
        <translation>Γεωγρ.Μήκος:</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="301"/>
        <source>Latitude:</source>
        <translation>Γεωγρ.Πλάτος:</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="304"/>
        <source>Size:</source>
        <translation>Μέγεθος:</translation>
    </message>
    <message>
        <location filename="../../src/panoramio.cpp" line="305"/>
        <source>Order:</source>
        <translation>Κατάταξη:</translation>
    </message>
</context>
<context>
    <name>Photobucket::DialogWidget</name>
    <message>
        <location filename="../../src/photobucket.cpp" line="275"/>
        <source>All of these words</source>
        <translation>&apos;Ολες οι λέξεις</translation>
    </message>
    <message>
        <location filename="../../src/photobucket.cpp" line="276"/>
        <source>Any of these words</source>
        <translation>Όποια λέξη</translation>
    </message>
    <message>
        <location filename="../../src/photobucket.cpp" line="279"/>
        <source>Search for:</source>
        <translation>Αναζήτηση γιά:</translation>
    </message>
    <message>
        <location filename="../../src/photobucket.cpp" line="293"/>
        <source>Photobucket item</source>
        <translation>Πρόσθεση αντικειμένου Photobucket</translation>
    </message>
    <message>
        <location filename="../../src/photobucket.cpp" line="294"/>
        <source>It can show offending or sexual explicit photos</source>
        <translation>Αφιλτράριστο περιεχόμενο μπορεί να δείξει προσβλητικό ή σκληρό πορνογραφικό θέαμα</translation>
    </message>
    <message>
        <location filename="../../src/photobucket.cpp" line="311"/>
        <source>Edit Photobucket item</source>
        <translation>Επεξεργασία αντικείμενου Photobucket</translation>
    </message>
    <message>
        <location filename="../../src/photobucket.cpp" line="317"/>
        <source>Add Photobucket item</source>
        <translation>Πρόσθεση αντικειμένου Photobucket</translation>
    </message>
</context>
<context>
    <name>Photobucket::Item</name>
    <message>
        <location filename="../../src/photobucket.cpp" line="81"/>
        <source>Text:</source>
        <translation>Κείμενο:</translation>
    </message>
    <message>
        <location filename="../../src/photobucket.cpp" line="82"/>
        <source>and</source>
        <translation>καί</translation>
    </message>
    <message>
        <location filename="../../src/photobucket.cpp" line="83"/>
        <source>or</source>
        <translation>ή</translation>
    </message>
</context>
<context>
    <name>Picasa::DialogWidget</name>
    <message>
        <location filename="../../src/picasa.cpp" line="255"/>
        <source>Search for:</source>
        <translation>Αναζήτηση γιά:</translation>
    </message>
    <message>
        <location filename="../../src/picasa.cpp" line="278"/>
        <source>Edit Picasa item</source>
        <translation>Σύνταξη αντικειμένου Picasa</translation>
    </message>
    <message>
        <location filename="../../src/picasa.cpp" line="283"/>
        <source>Add Picasa item</source>
        <translation>Πρόσθεση αντικειμένου Picasa</translation>
    </message>
</context>
<context>
    <name>Picasa::Item</name>
    <message>
        <location filename="../../src/picasa.cpp" line="47"/>
        <source>Text:</source>
        <translation>Κείμενο:</translation>
    </message>
</context>
<context>
    <name>Pikeo::DialogWidget</name>
    <message>
        <location filename="../../src/pikeo.cpp" line="268"/>
        <source>Search for:</source>
        <translation>Αναζήτηση γιά:</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="273"/>
        <source>Default</source>
        <translation>Προεπιλογή</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="274"/>
        <source>Most viewed</source>
        <translation>Περισσότερες εμφανίσεις</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="275"/>
        <source>Upload date</source>
        <translation>Ημερομηνία ανεβάσματος</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="276"/>
        <source>Date taken</source>
        <translation>Ημερομηνία λήψης</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="277"/>
        <source>Group add date</source>
        <translation>Ημερομηνία προσθήκης ομάδας</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="278"/>
        <source>Comment date</source>
        <translation>Ημερομηνία σχολίου</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="282"/>
        <source>Ascending</source>
        <translation>Αύξουσα</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="284"/>
        <source>Order:</source>
        <translation>Κατάταξη:</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="315"/>
        <source>Edit Pikeo item</source>
        <translation>Σύνταξη αντικειμένου Pikeo</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="322"/>
        <source>Add Pikeo item</source>
        <translation>Προσθήκη αντικειμένου Pikeo</translation>
    </message>
</context>
<context>
    <name>Pikeo::Item</name>
    <message>
        <location filename="../../src/pikeo.cpp" line="56"/>
        <source>Tags:</source>
        <translation>Ετικέτες:</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="57"/>
        <source>Order:</source>
        <translation>Κατάταξη:</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="61"/>
        <source>Default</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="62"/>
        <source>Most viewed</source>
        <translation>Περισσότερες εμφανίσεις</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="63"/>
        <source>Upload date</source>
        <translation>Ημερομηνία ανεβάσματος</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="64"/>
        <source>Date taken</source>
        <translation>Ημερομηνία λήψης</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="65"/>
        <source>Group add date</source>
        <translation>Ημερομηνία προσθήκης ομάδας</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="66"/>
        <source>Comment date</source>
        <translation>Ημερομηνία σχολίου</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="69"/>
        <source>ascending</source>
        <translation>Αύξουσα</translation>
    </message>
    <message>
        <location filename="../../src/pikeo.cpp" line="69"/>
        <source>descending</source>
        <translation>φθίνουσα</translation>
    </message>
</context>
<context>
    <name>PositionModel</name>
    <message>
        <location filename="../../src/settings.cpp" line="133"/>
        <source>Position</source>
        <translation>Θέση</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="136"/>
        <source>Picture smaller than screen on the left, greater than screen on the right</source>
        <translation>Εικόνα μικρότερη της οθόνης στ αριστερά, μεγαλύτερη της οθόνης στα δεξιά</translation>
    </message>
</context>
<context>
    <name>QColorDialog</name>
    <message>
        <location filename="../../src/settings.cpp" line="184"/>
        <source>Hu&amp;e:</source>
        <translation>Απόχ&amp;ρωση:</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="185"/>
        <source>&amp;Sat:</source>
        <translation>&amp;Κορ:</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="186"/>
        <source>&amp;Val:</source>
        <translation>&amp;Τιμ:</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="187"/>
        <source>&amp;Red:</source>
        <translation>Κόκκ&amp;ινο:</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="188"/>
        <source>&amp;Green:</source>
        <translation>&amp;Πράσινο:</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="189"/>
        <source>Bl&amp;ue:</source>
        <translation>&amp;Μπλέ:</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="190"/>
        <source>Select Color</source>
        <translation>Επιλέγξτε χρώμα</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="191"/>
        <source>&amp;Basic colors</source>
        <translation>&amp;Βασικά χρώματα</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="192"/>
        <source>&amp;Custom colors</source>
        <translation>Προσαρμοσμένα &amp;χρώματα</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="193"/>
        <source>&amp;Add to Custom Colors</source>
        <translation>Προσθήκ&amp;η στα προσαρμοσμένα χρώματα</translation>
    </message>
</context>
<context>
    <name>QDialogButtonBox</name>
    <message>
        <location filename="../../src/settings.cpp" line="176"/>
        <source>OK</source>
        <translation>ΟΚ</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="177"/>
        <source>Cancel</source>
        <translation>Άκυρο</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="178"/>
        <source>Reset</source>
        <translation>Επαναφορά</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="179"/>
        <source>&amp;Yes</source>
        <translation>&amp;Ναί</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="180"/>
        <source>&amp;No</source>
        <translation>&amp;Όχι</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="181"/>
        <source>Close</source>
        <translation>Κλείσιμο</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="182"/>
        <source>&amp;Close</source>
        <translation>&amp;Κλείσιμο</translation>
    </message>
</context>
<context>
    <name>QFileDialog</name>
    <message>
        <location filename="../../src/settings.cpp" line="195"/>
        <source>Directories</source>
        <translation>Κατάλογοι</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="196"/>
        <source>&amp;Open</source>
        <translation>&amp;Άνοιγμα</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="197"/>
        <source>&amp;Save</source>
        <translation>&amp;Αποθήκευση</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="198"/>
        <source>Open</source>
        <translation>Άνοιγμα</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="199"/>
        <source>%1 already exists.
Do you want to replace it?</source>
        <translation>%1 υπάρχει ήδη.
Θέλετε να το αντικαταστήσετε;</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="200"/>
        <source>%1
File not found.
Please verify the correct file name was given.</source>
        <translation>%1
Το αρχείο δεν βρέθηκε.
Παρακαλώ επαληθεύστε το σωστό όνομα αρχείου που δόθηκε.</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="201"/>
        <source>My Computer</source>
        <translation>Ο Υπολογιστής Μου</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="202"/>
        <source>&amp;Rename</source>
        <translation>&amp;Μετονομασία</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="203"/>
        <source>&amp;Delete</source>
        <translation>&amp;Διαγραφή</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="204"/>
        <source>Show &amp;hidden files</source>
        <translation>Εμφάνιση &amp;κρυφών αρχείων</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="205"/>
        <source>Back</source>
        <translation>Πίσω</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="206"/>
        <source>Parent Directory</source>
        <translation>Επάνω</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="207"/>
        <source>List View</source>
        <translation>Λίστα</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="208"/>
        <source>Detail View</source>
        <translation>Λεπτομέρειες</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="209"/>
        <source>Files of type:</source>
        <translation>Αρχεία τύπου:</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="210"/>
        <source>Directory:</source>
        <translation>Κατάλογος:</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="211"/>
        <source>%1
Directory not found.
Please verify the correct directory name was given.</source>
        <translation>%1
Κατάλογος δεν βρέθηκε.
Παρακαλώ επαληθεύστε το σωστό όνομα Κατάλογου που δόθηκε.</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="212"/>
        <source>&apos;%1&apos; is write protected.
Do you want to delete it anyway?</source>
        <translation>&apos;%1&apos; έχει προστασία εγγραφήςι.
Θέλετε να το διαγράψετε ούτως ή άλλως;</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="213"/>
        <source>Are sure you want to delete &apos;%1&apos;?</source>
        <translation>Θέλετε σίγουρα να διαγράψετε &apos;%1&apos;?</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="214"/>
        <source>Could not delete directory.</source>
        <translation>Δεν ήταν δυνατή η διαγραφή καταλόγου.</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="215"/>
        <source>Recent Places</source>
        <translation>Πρόσφατες Θέσεις</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="216"/>
        <source>Save As</source>
        <translation>Αποθήκευση ως</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="217"/>
        <source>Drive</source>
        <translation>Συσκευή</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="218"/>
        <source>File</source>
        <translation>Αρχείο</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="219"/>
        <source>Unknown</source>
        <translation>Άγνωστο</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="220"/>
        <source>Find Directory</source>
        <translation>Εύρεση Κατάλογου</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="221"/>
        <source>Show</source>
        <translation>Δείξε</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="222"/>
        <source>Forward</source>
        <translation>Προώθηση</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="223"/>
        <source>New Folder</source>
        <translation>Νέος Φάκελος</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="224"/>
        <source>&amp;New Folder</source>
        <translation>&amp;Νέος Φάκελος</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="225"/>
        <source>&amp;Choose</source>
        <translation>&amp;Επέλεξε</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="226"/>
        <source>Remove</source>
        <translation>Αφαίρεσε</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="227"/>
        <source>File &amp;name:</source>
        <translation>Όνομα &amp;αρχείου:</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="228"/>
        <source>Look in:</source>
        <translation>Κοίτα στο:</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="229"/>
        <source>Create New Folder</source>
        <translation>Δημιουργία Νέος Φάκελος</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../src/utils.cpp" line="76"/>
        <source>All image files</source>
        <translation>Όλα τα αρχεία εικόνας</translation>
    </message>
    <message>
        <location filename="../../src/utils.cpp" line="80"/>
        <source>files</source>
        <translation>αρχεία</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="31"/>
        <source>Centered</source>
        <translation>Στο κέντρο</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="34"/>
        <source>Tiled</source>
        <translation>Πλακάκια</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="37"/>
        <source>Center Tiled</source>
        <translation>Στο κέντρο πλακάκια</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="40"/>
        <source>Centered Maxpect</source>
        <translation>Στο κέντρο  Maxpect</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="43"/>
        <source>Tiled Maxpect</source>
        <translation>Πλακάκια  Maxpect</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="46"/>
        <source>Scaled</source>
        <translation>Κλιμακωτά</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="49"/>
        <source>Centered Auto Fit</source>
        <translation>Στο κέντρο Auto Fit</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="52"/>
        <source>Scale &amp; Crop</source>
        <translation>Κλίμακα &amp; Περικοπή</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="55"/>
        <source>Symmetrical Tiled</source>
        <translation>Συμμετρικά πλακάκια</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="58"/>
        <source>Mirrored Tiled</source>
        <translation>Ανεστραμένα Πλακάκια</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="61"/>
        <source>Symmetrical Mirrored Tiled</source>
        <translation>Συμμετρικά Ανεστραμένα Πλακάκια</translation>
    </message>
</context>
<context>
    <name>QProgressDialog</name>
    <message>
        <location filename="../../src/history.cpp" line="340"/>
        <source>Cancel</source>
        <translation>Άκυρο</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../../src/settings.cpp" line="168"/>
        <location filename="../../src/settings.cpp" line="173"/>
        <location filename="../../src/settings.cpp" line="514"/>
        <source>Settings</source>
        <translation>Ρυθμίσεις</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="239"/>
        <source>Left</source>
        <translation>Αριστερά</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="240"/>
        <source>Right</source>
        <translation>Δεξιά</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="243"/>
        <source>kBytes</source>
        <translation>kBytes</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="244"/>
        <source>MBytes</source>
        <translation>MBytes</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="245"/>
        <source>GBytes</source>
        <translation>GBytes</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/settings.cpp" line="248"/>
        <source>day(s)</source>
        <translation>
            <numerusform>ημέρα(ες)</numerusform>
            <numerusform>ημέρες</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/settings.cpp" line="249"/>
        <source>month(s)</source>
        <translation>
            <numerusform>μήνας(ες)</numerusform>
            <numerusform>μήνες</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/settings.cpp" line="299"/>
        <location filename="../../src/settings.cpp" line="524"/>
        <source>second(s)</source>
        <translation>
            <numerusform>δευτερόλεπτο(α)</numerusform>
            <numerusform>δευτερόλεπτα</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/settings.cpp" line="300"/>
        <location filename="../../src/settings.cpp" line="525"/>
        <source>minute(s)</source>
        <translation>
            <numerusform>λεπτό(α)</numerusform>
            <numerusform>λεπτά</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/settings.cpp" line="301"/>
        <location filename="../../src/settings.cpp" line="526"/>
        <source>hour(s)</source>
        <translation>
            <numerusform>ώρα(ες)</numerusform>
            <numerusform>ώρες</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="453"/>
        <source>Set position</source>
        <translation>Ορίστε θέση</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="514"/>
        <source>Changes won&apos;t be applied. Are you sure?</source>
        <translation>Οι αλλαγές δεν θα εφαρμοστούν. Είστε σίγουροι;</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="599"/>
        <source>Clear history</source>
        <translation>Καθαρισμός ιστορικού</translation>
    </message>
    <message>
        <location filename="../../src/settings.cpp" line="599"/>
        <source>Are you sure?</source>
        <translation> Είστε σίγουροι;</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="34"/>
        <source>General options</source>
        <translation>Γενικές Επιλογές</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="42"/>
        <source>Interval:</source>
        <translation>Διάστημα:</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="69"/>
        <source>Border:</source>
        <translation>Περιθώριο:</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="86"/>
        <location filename="../../ui/settings.ui" line="237"/>
        <source>Position:</source>
        <translation>Θέση:</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="144"/>
        <source>Main</source>
        <translation>Κύριο</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="153"/>
        <source>Choose in random order</source>
        <translation>Επιλογή με τυχαία σειρά</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="160"/>
        <source>Switch background on play</source>
        <translation>Αλλαγή φόντου στο παίξτε</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="167"/>
        <source>Play automatically on application start</source>
        <translation>Αναπαραγωγή αυτόματα στην έναρξη της εφαρμογής</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="174"/>
        <source>Disable splash screen</source>
        <translation>Απενεργοποίηση οθόνης εμφάνισης</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="181"/>
        <source>Quit after background change</source>
        <translation>Έξοδος μετά την αλλαγή φόντου</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="188"/>
        <source>Start automatically when system starts</source>
        <translation>Εκκίνηση αυτόματα στην έναρξη του συστήματος</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="195"/>
        <source>Only use landscape-oriented photos</source>
        <translation>Χρήση φωτογραφιών μόνο με προσανατολισμό τοπίου</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="202"/>
        <source>Rotate images according to EXIF information</source>
        <translation>Περιστροφή φωτογραφιών σύμφωνα με τις πληροφορίες EXIF</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="211"/>
        <source>View info on photo</source>
        <translation>Προβολή πληροφοριών πάνω στις φωτογραφίες</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="269"/>
        <source>View info in system tray tooltip</source>
        <translatorcomment>system tray-γραμμής ειδοποιήσεων</translatorcomment>
        <translation>Προβολή πληροφοριών στο αναδυόμενο παράθυρο της γραμμής ειδοποιήσεων</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="276"/>
        <source>Use full desktop area</source>
        <translation>Χρήση πλήρους επιφάνειας εργασίας</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="285"/>
        <source>Photo has to be</source>
        <translation>Η φωτογραφία πρέπει να είναι</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="296"/>
        <source>independent of</source>
        <translation>Ανεξάρτητα από</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="301"/>
        <source>at least 1/2 of</source>
        <translation>τουλάχιστον 1/2 </translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="306"/>
        <source>at least 3/4 of</source>
        <translation>τουλάχιστον 3/4 </translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="311"/>
        <source>bigger than</source>
        <translation>Μεγαλύτερο από</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="319"/>
        <source>desktop&apos;s size</source>
        <translation>το μέγεθος της επιφάνειας εργασίας</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="343"/>
        <source>Don&apos;t save locally remote photos if free disk space goes below</source>
        <translation>Μην αποθηκεύετε τοπικά απομακρυσμένες φωτογραφίες αν ο ελεύθερος χώρος στο δίσκο είναι λιγότερος από</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="381"/>
        <source>Store images in history for</source>
        <translation>Διατήρηση φωτογραφιών στο ιστορικό για</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="398"/>
        <source>Clear</source>
        <translation>Καθάρισε</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="630"/>
        <source>Engines</source>
        <translation>Eνότητες</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="750"/>
        <source>Available modules:</source>
        <translation>Διαθέσιμες ενότητες:</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="757"/>
        <source>Active modules:</source>
        <translation>Ενεργές ενότητες:</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="421"/>
        <source>Network</source>
        <translation>Δίκτυο</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="433"/>
        <source>Direct connection</source>
        <translation>Απ΄ευθείας σύνδεση</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="443"/>
        <source>Proxy connection</source>
        <translation>Σύνδεση μέσω Proxy</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="467"/>
        <source>Use system proxy</source>
        <translatorcomment>Proxy-Διαμεσολαβητης</translatorcomment>
        <translation>Χρήση Proxy συστήματος</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="477"/>
        <source>Use custom proxy</source>
        <translation>Χρήση προσαρμοσμένου Proxy</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="487"/>
        <source>Server:</source>
        <translatorcomment>Server-υπολογιστής εξυπηρέτησης δικτύου</translatorcomment>
        <translation>υπολογιστής εξυπηρέτησης δικτύου:</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="497"/>
        <source>Port:</source>
        <translation>Θύρα:</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="547"/>
        <source>Authentication</source>
        <translation>Πιστοποίηση</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="562"/>
        <source>Username:</source>
        <translation>&apos;Ονομα χρήστη:</translation>
    </message>
    <message>
        <location filename="../../ui/settings.ui" line="579"/>
        <source>Password:</source>
        <translation>Κωδικός εισόδου:</translation>
    </message>
</context>
<context>
    <name>SmugMug::DialogWidget</name>
    <message>
        <location filename="../../src/smugmug.cpp" line="252"/>
        <source>Search for:</source>
        <translation>Αναζήτηση γιά:</translation>
    </message>
    <message>
        <location filename="../../src/smugmug.cpp" line="275"/>
        <source>Edit SmugMug item</source>
        <translation>Επεξεργασία αντικείμενου SmugMug</translation>
    </message>
    <message>
        <location filename="../../src/smugmug.cpp" line="280"/>
        <source>Add SmugMug item</source>
        <translation>Προσθήκη αντικείμενου SmugMug</translation>
    </message>
</context>
<context>
    <name>SmugMug::Item</name>
    <message>
        <location filename="../../src/smugmug.cpp" line="47"/>
        <source>Text:</source>
        <translation>Κείμενο:</translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <location filename="../../src/main.cpp" line="109"/>
        <source>Loading Files module ...</source>
        <translation>Διαδικασία φόρτωσης Αρχείων ...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="116"/>
        <source>Loading Folders module ...</source>
        <translation>Διαδικασία φόρτωσης Φακέλων ...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="123"/>
        <source>Loading Flickr module ...</source>
        <translation>Διαδικασία φόρτωσης Flickr ...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="137"/>
        <source>Loading Panoramio module ...</source>
        <translation>Διαδικασία φόρτωσης Panoramio ...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="151"/>
        <source>Loading Ipernity module ...</source>
        <translation>Διαδικασία φόρτωσης Ipernity ...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="158"/>
        <source>Loading Photobucket module ...</source>
        <translation>Διαδικασία φόρτωσης Photobucket ...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="165"/>
        <source>Loading Buzznet module ...</source>
        <translation>Διαδικασία φόρτωσης Buzznet ...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="172"/>
        <source>Loading Picasa module ...</source>
        <translation>Διαδικασία φόρτωσης Picasa ...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="179"/>
        <source>Loading SmugMug module ...</source>
        <translation>Διαδικασία φόρτωσης SmugMug ...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="193"/>
        <source>Loading Google module ...</source>
        <translation>Διαδικασία φόρτωσης Google ...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="200"/>
        <source>Loading Vladstudio module ...</source>
        <translation>Διαδικασία φόρτωσης Vladstudio ...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="207"/>
        <source>Loading deviantART module ...</source>
        <translation>Διαδικασία φόρτωσης deviantART ...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="214"/>
        <source>Loading settings ...</source>
        <translation>Φόρτωση ρυθμίσεων ...</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="221"/>
        <source>Launching Wally ...</source>
        <translation>Φόρτωση Wally ...</translation>
    </message>
    <message>
        <location filename="../../src/splash.cpp" line="46"/>
        <source>Author:</source>
        <translation>Δημιουργός:</translation>
    </message>
</context>
<context>
    <name>Viewer</name>
    <message>
        <location filename="../../ui/viewer.ui" line="9"/>
        <source>Right-click on photo to show actions</source>
        <translation>Δεξί-κλικ γιά εμφάνιση κύριου μενού</translation>
    </message>
    <message>
        <location filename="../../ui/viewer.ui" line="63"/>
        <source>Fit to window</source>
        <translatorcomment>Προσαρμογή στο παράθυρο</translatorcomment>
        <translation>Προσαρμογή στο παράθυρο</translation>
    </message>
    <message>
        <location filename="../../ui/viewer.ui" line="72"/>
        <source>Show full image</source>
        <translatorcomment>Εμφάνιση πλήρους εικόνας</translatorcomment>
        <translation>Εμφάνιση πλήρους εικόνας</translation>
    </message>
    <message>
        <location filename="../../ui/viewer.ui" line="81"/>
        <source>Zoom in</source>
        <translation>Μεγένθυση</translation>
    </message>
    <message>
        <location filename="../../ui/viewer.ui" line="90"/>
        <source>Zoom out</source>
        <translation>Σμίκρυνση</translation>
    </message>
    <message>
        <location filename="../../ui/viewer.ui" line="99"/>
        <source>Rotate clockwise</source>
        <translation>Περιστροφή δεξιόστροφα</translation>
    </message>
    <message>
        <location filename="../../ui/viewer.ui" line="108"/>
        <source>Rotate c. clockwise</source>
        <translatorcomment>Περιστροφή αριστερόστρφα</translatorcomment>
        <translation></translation>
    </message>
</context>
<context>
    <name>Vladstudio::DialogWidget</name>
    <message>
        <location filename="../../src/vladstudio.cpp" line="325"/>
        <source>All</source>
        <translation>Όλα</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="326"/>
        <source>Abstract art</source>
        <translation>Αφηρημένη τέχνη</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="327"/>
        <source>Creatures</source>
        <translation>Πλάσματα</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="328"/>
        <source>Illustrations</source>
        <translation>Εικονογράφηση</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="329"/>
        <source>Photos</source>
        <translation>Φωτογραφίες</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="334"/>
        <source>By ID</source>
        <translation>από ταυτότητα</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="335"/>
        <source>By view count</source>
        <translation>από καταμέτρηση θέασης</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="340"/>
        <source>Ascending</source>
        <translation>Αύξουσα</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="341"/>
        <source>Descending</source>
        <translation>Φθίνουσα</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="344"/>
        <source>Category:</source>
        <translation>Κατηγορία:</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="345"/>
        <source>Order:</source>
        <translation>Κατάταξη:</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="346"/>
        <source>Direction:</source>
        <translation>Κατεύθυνση:</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="368"/>
        <source>Edit Vladstudio item</source>
        <translation>Επεξεργασία αντικείμενου Vladstudio</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="375"/>
        <source>Add Vladstudio item</source>
        <translation>Προσθήκη αντικείμενου Vladstudio</translation>
    </message>
</context>
<context>
    <name>Vladstudio::Item</name>
    <message>
        <location filename="../../src/vladstudio.cpp" line="42"/>
        <source>All categories</source>
        <translation>Όλες οι κατηγορίες</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="46"/>
        <source>Abstract art</source>
        <translation>Αφηρημένη τέχνη</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="50"/>
        <source>Creatures</source>
        <translation>Πλάσματα</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="54"/>
        <source>Illustrations</source>
        <translation>Εικονογράφησεις</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="58"/>
        <source>Photos</source>
        <translation>Φωτογραφίες</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="89"/>
        <source>by Id</source>
        <translation>από ταυτότητα</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="93"/>
        <source>by view count</source>
        <translation>από καταμέτρηση θέασης</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="105"/>
        <source>ascending</source>
        <translation>aύξουσα</translation>
    </message>
    <message>
        <location filename="../../src/vladstudio.cpp" line="109"/>
        <source>descending</source>
        <translation>φθίνουσα</translation>
    </message>
</context>
<context>
    <name>Wally::Application</name>
    <message>
        <location filename="../../src/wally.cpp" line="621"/>
        <source>Cancel</source>
        <translation>Άκυρο</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="623"/>
        <location filename="../../src/wally.cpp" line="2114"/>
        <source>Play</source>
        <translation>Αναπαραγωγή</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="625"/>
        <location filename="../../src/wally.cpp" line="2094"/>
        <source>Pause</source>
        <translation>Παύση</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="626"/>
        <source>Next photo</source>
        <translation>Επόμενη φωτογραφία</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="627"/>
        <source>Save photo...</source>
        <translation>Αποθήκευση φωτογραφίας...</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="628"/>
        <source>Get EXIF info...</source>
        <translation>Πάρτε EXIF πληροφορίες...</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="629"/>
        <source>Settings...</source>
        <translation>Ρυθμίσεις...</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="630"/>
        <source>Explore source</source>
        <translation>Εξερεύνηση προέλευσης</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="631"/>
        <source>About...</source>
        <translation>Περί...</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="632"/>
        <source>History...</source>
        <translation>Ιστορικό...</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="633"/>
        <source>About Qt...</source>
        <translation>Περί Qt...</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="634"/>
        <source>Quit</source>
        <translation>Έξοδος</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="635"/>
        <source>Languages</source>
        <translation>Γλώσσες</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="637"/>
        <source>English</source>
        <translation>Αγγλικά</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="638"/>
        <source>Italian</source>
        <translation>Ιταλικά</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="639"/>
        <source>Spanish</source>
        <translation>Ισπανικά</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="640"/>
        <source>German</source>
        <translation>Γερμανικά</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="641"/>
        <source>French</source>
        <translation>Γαλλικά</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="642"/>
        <source>Russian</source>
        <translation>Ρωσικά</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="643"/>
        <source>Portuguese (Brazil)</source>
        <translation>Πορτογαλικά(Βραζιλίας)</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="644"/>
        <source>Czech</source>
        <translation>Τσέχικα</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="645"/>
        <source>Polish</source>
        <translation>Πολωνέζικα</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="646"/>
        <source>Chinese (Simplified)</source>
        <translation>Κινέζικα (απλοποιημένα)</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="647"/>
        <source>Chinese (Traditional)</source>
        <translation>Κινέζικα (παραδοσιακά)</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="648"/>
        <source>Catalan</source>
        <translation>Καταλανικά</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="649"/>
        <source>Greek</source>
        <translation>Ελληνικά</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="650"/>
        <source>Korean</source>
        <translation>Κορεατικά</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="651"/>
        <source>Hungarian</source>
        <translation>Ουγγρικά</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="652"/>
        <source>Danish</source>
        <translation>Δανέζικα</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="653"/>
        <source>Swedish</source>
        <translation>Σουηδικά</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="654"/>
        <source>Turkish</source>
        <translation>Τουρκικά</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="1685"/>
        <source>Wally Error</source>
        <translation>Σφάλμα Wally</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="1685"/>
        <source>Active Desktop must be disabled</source>
        <translation>Active Desktop πρέπει να απενεργοποιηθεί</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="1774"/>
        <location filename="../../src/wally.cpp" line="2065"/>
        <source>by:</source>
        <translation>από:</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="1783"/>
        <source>Location:</source>
        <translation>Θέση:</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="1791"/>
        <location filename="../../src/wally.cpp" line="2070"/>
        <source>Engine:</source>
        <translation>Μηχανή:</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="2154"/>
        <location filename="../../src/wally.cpp" line="2157"/>
        <source>Save photo</source>
        <translation>Αποθήκευση φωτογραφίας</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="2155"/>
        <location filename="../../src/wally.cpp" line="2159"/>
        <source>Images (*.png *.xpm *.jpg)</source>
        <translation>Εικόνες (*.png *.xpm *.jpg)</translation>
    </message>
    <message>
        <location filename="../../src/wally.cpp" line="2654"/>
        <source>Right-click to show main menu</source>
        <translation>Δεξί κλικ γιά εμφάνιση κύριου μενού</translation>
    </message>
</context>
<context>
    <name>Yahoo::DialogWidget</name>
    <message>
        <location filename="../../src/yahoo.cpp" line="268"/>
        <source>All of these words</source>
        <translation>&apos;Ολες οι λέξεις</translation>
    </message>
    <message>
        <location filename="../../src/yahoo.cpp" line="269"/>
        <source>Any of these words</source>
        <translation>Όποια λέξη</translation>
    </message>
    <message>
        <location filename="../../src/yahoo.cpp" line="272"/>
        <source>Search for:</source>
        <translation>Αναζήτηση γιά:</translation>
    </message>
    <message>
        <location filename="../../src/yahoo.cpp" line="277"/>
        <source>Filter content</source>
        <translation>Φίλτρο περιεχομένου</translation>
    </message>
    <message>
        <location filename="../../src/yahoo.cpp" line="297"/>
        <source>Yahoo! item</source>
        <translation>Yahoo! Αντικείμενο</translation>
    </message>
    <message>
        <location filename="../../src/yahoo.cpp" line="298"/>
        <source>Unfiltered content can show offending or sexual explicit photos</source>
        <translation>Αφιλτράριστο περιεχόμενο μπορεί να δείξει σκληρό πορνογραφικό θέαμα</translation>
    </message>
    <message>
        <location filename="../../src/yahoo.cpp" line="309"/>
        <source>Edit Yahoo! item</source>
        <translation>Επεξεργασία αντικείμενου Yahoo!</translation>
    </message>
    <message>
        <location filename="../../src/yahoo.cpp" line="317"/>
        <source>Add Yahoo! item</source>
        <translation>Προσθέστε αντικείμενο Yahoo!</translation>
    </message>
</context>
<context>
    <name>Yahoo::Item</name>
    <message>
        <location filename="../../src/yahoo.cpp" line="56"/>
        <source>Tags:</source>
        <translation>Ετικέτες:</translation>
    </message>
    <message>
        <location filename="../../src/yahoo.cpp" line="58"/>
        <source>and</source>
        <translation>καί</translation>
    </message>
    <message>
        <location filename="../../src/yahoo.cpp" line="58"/>
        <source>or</source>
        <translation>ή</translation>
    </message>
    <message>
        <location filename="../../src/yahoo.cpp" line="61"/>
        <source>content filtered</source>
        <translation>φιλτραρισμένο περιεχόμενο</translation>
    </message>
</context>
</TS>
