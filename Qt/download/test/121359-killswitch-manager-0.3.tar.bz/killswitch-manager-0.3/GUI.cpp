#include "GUI.h"
#include "killswitch.h"
#include "urf-killswitch.h"
#include <QPushButton>
#include <QApplication>
#include <QKeyEvent>
#include <QCheckBox>
#include <QLabel>
#include <QGridLayout>
#include <QVBoxLayout>
#include <QString>
#include <QDebug>
#include <QPixmap>
#include <QDir>
#include <QCoreApplication>
#include <QDBusArgument>
#include <QDBusInterface>

KillswitchManager *pManager;
URfkillSwitchManager *urfManager;
bool urfkill_running;

GUI::GUI(QWidget *parent)
    :QWidget(parent, Qt::FramelessWindowHint | Qt::WindowSystemMenuHint)
{
    QVBoxLayout *vbox = new QVBoxLayout();

    QPushButton *quit = new QPushButton("X");
    quit->setFixedSize(20,20);
    connect(quit, SIGNAL(clicked()), qApp, SLOT(quit()));
    vbox->addWidget(quit, 0, Qt::AlignRight);
    vbox->setSpacing(10);

    qDebug() << "Loading manager\n";    
    urfkill_running = urfManager->ownURfkillService();
    if (urfkill_running) {
        qDebug() << "Listen killswitches status via URfkill" << endl;
        urfManager = new URfkillSwitchManager;
        urfManager->loadDevices();
    } else {
        qDebug() << "Listen killswitches status via HAL" << endl;
        pManager = new KillswitchManager;
        pManager->loadDevices();
    }

    QGridLayout *layout = new QGridLayout();
    layout->setSpacing(18);

    if(urfkill_running) {
        for(int i = 0; i < urfManager->deviceList.length(); i++) {
            QCheckBox *button = new QCheckBox();

            QLabel *icon = new QLabel();

            QFileInfo fi = QString(":/resources/"+urfManager->urf_get_type(urfManager->deviceList[i]->urf_type)+".png");
            QPixmap pixmap;
            if(fi.exists()) {
                pixmap = QString(":/resources/"+urfManager->urf_get_type(urfManager->deviceList[i]->urf_type)+".png");
            }else{
                pixmap = QString(":/resources/unknown.png");
            }

            icon->setPixmap(pixmap);

            if(urfManager->urf_get_state(urfManager->deviceList[i]->urf_index) == 1){
                button->setChecked(1);
                icon->setEnabled(true);
            }else{
                button->setChecked(0);
                icon->setEnabled(false);
            }

            connect(button, SIGNAL(stateChanged(int)), this, SLOT(urfChangeBlock()));

            QLabel *label = new QLabel();
            label->setTextFormat(Qt::RichText);
            QString deviceName(urfManager->urf_get_type(urfManager->deviceList[i]->urf_type));
            deviceName[0]=deviceName[0].toUpper();
            label->setText(tr(deviceName.toStdString().c_str())+"<br><i><small><font style=\"color: grey\">"+tr("Device name")+": "+urfManager->deviceList[i]->urf_name+"</font></small></<i>");

            layout->addWidget(icon,i,0);
            layout->addWidget(label,i,1);
            layout->addWidget(button,i,2);

            ItemObjects list;
            list.number = i;
            list.a = icon;
            list.b = button;

            hash.insert(button,list);
        }
        QDBusConnection::systemBus().connect(URFKILL_DBUS_SERVICE,
                                URFKILL_DBUS_PATH,
                                URFKILL_DBUS_INTERFACE,
                                "RfkillChanged",
                                this,
                                SLOT(urfStateChanged(uint, uint, int, uint, uint, QString)));
    } else {
        for(int i = 0; i < pManager->deviceList.length(); i++) {
            QCheckBox *button = new QCheckBox();

            QLabel *icon = new QLabel();

            QFileInfo fi = QString(":/resources/"+pManager->deviceList[i]->type+".png");
            QPixmap pixmap;
            if(fi.exists()) {
                pixmap = QString(":/resources/"+pManager->deviceList[i]->type+".png");
            }else{
                pixmap = QString(":/resources/unknown.png");
            }

            icon->setPixmap(pixmap);

            if(pManager->deviceList[i]->get_state()==true){
                button->setChecked(1);
                icon->setEnabled(true);
            }else{
                button->setChecked(0);
                icon->setEnabled(false);
            }

            connect(button, SIGNAL(stateChanged(int)), this, SLOT(changeState()));

            QLabel *label = new QLabel();
            label->setTextFormat(Qt::RichText);
            QString deviceName(pManager->deviceList[i]->type);
            deviceName[0]=deviceName[0].toUpper();
            label->setText(tr(deviceName.toStdString().c_str())+"<br><i><small><font style=\"color: grey\">"+tr("Device name")+": "+pManager->deviceList[i]->name+"</font></small></<i>");

            layout->addWidget(icon,i,0);
            layout->addWidget(label,i,1);
            layout->addWidget(button,i,2);

            ItemObjects list;
            list.number = i;
            list.a = icon;
            list.b = button;

            hash.insert(button,list);
        }
    }

    QFrame *topline = new QFrame();
    topline->setFrameShape(QFrame::HLine);
    vbox->addWidget(topline);

    vbox->addLayout(layout);

    QFrame *bottomline = new QFrame();
    bottomline->setFrameShape(QFrame::HLine);
    vbox->addWidget(bottomline);

    this->setLayout(vbox);

    //extern void centerWin(QWidget* widget);
    //centerWin(window);
}

// add FocusOut event: http://doc.trolltech.com/4.3/qfocusevent.html
// Check out this script, is it better? : http://labs.trolltech.com/blogs/2007/08/21/fade-effects-a-blast-from-the-past/
void GUI::keyPressEvent(QKeyEvent *event) {
   if (event->key() == Qt::Key_Escape) {
      // qApp->quit();
       QTimeLine *timeLine = new QTimeLine(330, this);
       timeLine->setFrameRange(100,0);
       connect(timeLine, SIGNAL(frameChanged(int)), this, SLOT(onClick(int)));
       timeLine->start();

       //qApp->quit();
       }
}


void GUI::onClick(int nbr) {
    QTextStream out(stdout);
    double pgr = nbr/100.0;
    this->setWindowOpacity(pgr);
    if (nbr<=0)
        qApp->quit();
}


void GUI::changeState() {
    QCheckBox* combo = qobject_cast<QCheckBox*>(sender());
    int state = combo->checkState();

    if (state == 0) {
        qDebug() << "Turning off " << pManager->deviceList[hash[combo].number]->type << " device ...";
        pManager->deviceList[hash[combo].number]->set_state(0); //ask for a return!!
        hash[combo].a->setEnabled(false);
    } else {
        qDebug() << "Turning on " << pManager->deviceList[hash[combo].number]->type << " device...";
        pManager->deviceList[hash[combo].number]->set_state(1); //ask for a return!!
        hash[combo].a->setEnabled(true);
    }


}

void GUI::urfChangeBlock() {
    QCheckBox* combo = qobject_cast<QCheckBox*>(sender());
    int state = combo->checkState();

    if (state == 0) {
        urfManager->urf_set_block_idx(urfManager->deviceList[hash[combo].number]->urf_index);
        hash[combo].a->setEnabled(false);
    } else {
        urfManager->urf_set_unblock_idx(urfManager->deviceList[hash[combo].number]->urf_index);
        hash[combo].a->setEnabled(true);
    }

}

void GUI::urfStateChanged(uint index, uint type, int op, uint soft, uint hard, QString name) {
    qDebug() << "*killswitch status changed...*";

    urfManager->urf_show_all_info();

    qDebug() << endl;

}
