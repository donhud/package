#ifndef URFKILLSWITCH_H
#define URFKILLSWITCH_H

#include <QList>
#include <QString>
#include <QVariant>

#define URFKILL_DBUS_SERVICE    "org.freedesktop.URfkill"
#define URFKILL_DBUS_PATH       "/org/freedesktop/URfkill"
#define URFKILL_DBUS_INTERFACE  "org.freedesktop.URfkill"
#define DBUS_SERVICE            "org.freedesktop.DBus"
#define DBUS_PATH               "/org/freedesktop/DBus"
#define DBUS_INTERFACE          "org.freedesktop.DBus"

class QDBusArgument;

struct URfkillState {
    uint index;
    uint type;
    int op;
    uint soft;
    uint hard;
    QString name;
};

struct UrfkillswitchInfo {
    int type;
    int state;
    uint soft;
    uint hard;
    QString name;
};

Q_DECLARE_METATYPE(URfkillState);
Q_DECLARE_METATYPE(QList<URfkillState>);


class urfDevice {
  public:
    uint urf_index;
    uint urf_type;
    int urf_op;
    uint urf_soft;
    uint urf_hard;
    QString urf_name;

    urfDevice(uint, uint, int, uint, uint, QString);
};

class URfkillSwitchManager {
  public:
    bool ownURfkillService();
    void loadDevices();
    QList<urfDevice*> deviceList;

    void urf_set_block_idx(uint);
    void urf_set_unblock_idx(uint);
    QString urf_get_type(uint);
    int urf_get_state(uint);
    void urf_show_all_info();
};

const QDBusArgument &operator>>(const QDBusArgument &argument, URfkillState &urfkillstate);
const QDBusArgument &operator<<(QDBusArgument &argument, const URfkillState &urfkillstate);
const QDebug operator<<(QDebug debug, const URfkillState &urfkillstate);
const QDebug operator<<(QDebug debug, const QList<URfkillState> &urfkillstate);

#endif // URFKILLSWITCH_H
