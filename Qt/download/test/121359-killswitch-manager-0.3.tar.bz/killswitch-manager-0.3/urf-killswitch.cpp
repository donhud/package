#include <urf-killswitch.h>
#include <QObject>
#include <QList>
#include <QString>
#include <QDBusInterface>
#include <QDBusReply>
#include <QDebug>
#include <QDBusArgument>

enum URfkillType {
    RFKILL_TYPE_ALL = 0,
    RFKILL_TYPE_WLAN,
    RFKILL_TYPE_BLUETOOTH,
    RFKILL_TYPE_UWB,
    RFKILL_TYPE_WIMAX,
    RFKILL_TYPE_WWAN,
    RFKILL_TYPE_GPS,
    RFKILL_TYPE_FM,
    NUM_RFKILL_TYPES,
};

urfDevice::urfDevice(uint index, uint type, int op, uint soft, uint hard, QString name) {
    this->urf_index = index;
    this->urf_type = type;
    this->urf_op = op;
    this->urf_soft = soft;
    this->urf_hard = hard;
    this->urf_name = name;
}

const QDBusArgument &operator>>(const QDBusArgument &argument, URfkillState &urfkillstate) {
    argument.beginStructure();
    argument >> urfkillstate.index >> urfkillstate.type >> urfkillstate.op >> urfkillstate.soft >> urfkillstate.hard >> urfkillstate.name;
    argument.endStructure();
    return argument;
}

const QDBusArgument &operator<<(QDBusArgument &argument, const URfkillState &urfkillstate) {
    argument.beginStructure();
    argument << urfkillstate.index << urfkillstate.type << urfkillstate.op << urfkillstate.soft << urfkillstate.hard << urfkillstate.name;
    argument.endStructure();
    return argument;
}

const QDebug operator<<(QDebug debug, const URfkillState &urfkillstate) {
    debug << urfkillstate.index << urfkillstate.type << urfkillstate.op << urfkillstate.soft << urfkillstate.hard << urfkillstate.name;
    return debug;
}

const QDebug operator<<(QDebug debug, const QList<URfkillState> &urfkillstate) {
    foreach(URfkillState rs, urfkillstate) debug << rs;
    return debug;
}

void URfkillSwitchManager::loadDevices() {

    QTextStream out(stdout);
    QDBusConnection conn = QDBusConnection::systemBus();
    QDBusInterface urfkill(URFKILL_DBUS_SERVICE,URFKILL_DBUS_PATH,URFKILL_DBUS_INTERFACE, conn);

    QDBusMessage msg = urfkill.call("GetAll");

    QList<URfkillState> devices = qdbus_cast<QList<URfkillState> >(msg.arguments().at(0));

    urfDevice * uDevice;
    foreach(URfkillState rs, devices) {
        uDevice = new urfDevice(rs.index, rs.type, rs.op, rs.soft, rs.hard, rs.name);
        deviceList.append(uDevice);
    }
}

void URfkillSwitchManager::urf_set_block_idx(uint idx) {
    QDBusConnection conn = QDBusConnection::systemBus();
    QDBusInterface iface(URFKILL_DBUS_SERVICE,URFKILL_DBUS_PATH,URFKILL_DBUS_INTERFACE, conn);
    iface.call("BlockIdx", idx);
}

void URfkillSwitchManager::urf_set_unblock_idx(uint idx) {
    QDBusConnection conn = QDBusConnection::systemBus();
    QDBusInterface iface(URFKILL_DBUS_SERVICE,URFKILL_DBUS_PATH,URFKILL_DBUS_INTERFACE, conn);
    iface.call("UnblockIdx", idx);
}

QString URfkillSwitchManager::urf_get_type(uint urf_type) {
    switch(urf_type) {
        case RFKILL_TYPE_ALL:
            return "all";
        case RFKILL_TYPE_WLAN:
            return "wlan";
        case RFKILL_TYPE_BLUETOOTH:
            return "bluetooth";
        case RFKILL_TYPE_UWB:
            return "uwb";
        case RFKILL_TYPE_WIMAX:
            return "wimax";
        case RFKILL_TYPE_WWAN:
            return "wwan";
        case RFKILL_TYPE_GPS:
            return "gps";
        case RFKILL_TYPE_FM:
            return "fm";
        default:
            return "unknown";
    }
}

int URfkillSwitchManager::urf_get_state(uint idx) {
    QDBusConnection conn = QDBusConnection::systemBus();
    QDBusInterface urf_interface(URFKILL_DBUS_SERVICE,URFKILL_DBUS_PATH,URFKILL_DBUS_INTERFACE, conn);
    QDBusMessage msg = urf_interface.call("GetKillswitch", idx);

    QList<QVariant> killswitch_data = msg.arguments();

    UrfkillswitchInfo urfkillswitchinfo;
    urfkillswitchinfo.type = killswitch_data.at(0).toInt();
    urfkillswitchinfo.state = killswitch_data.at(1).toInt();
    urfkillswitchinfo.soft = killswitch_data.at(2).toUInt();
    urfkillswitchinfo.hard = killswitch_data.at(3).toUInt();
    urfkillswitchinfo.name = killswitch_data.at(4).toString();

    return urfkillswitchinfo.state;
}

bool URfkillSwitchManager::ownURfkillService() {
    QDBusConnection conn = QDBusConnection::systemBus();
    QDBusInterface checkURfkill(DBUS_SERVICE, DBUS_PATH, DBUS_INTERFACE, conn);
    QDBusReply<bool> rep = checkURfkill.call("NameHasOwner", "org.freedesktop.URfkill");

    return rep.value();
}

void URfkillSwitchManager::urf_show_all_info() {
    QTextStream out(stdout);
    QDBusConnection conn = QDBusConnection::systemBus();
    QDBusInterface urfkill(URFKILL_DBUS_SERVICE,URFKILL_DBUS_PATH,URFKILL_DBUS_INTERFACE, conn);

    QDBusMessage msg = urfkill.call("GetAll");

    QList<URfkillState> devices = qdbus_cast<QList<URfkillState> >(msg.arguments().at(0));

    foreach(URfkillState rs, devices) {
        qDebug() << "Killswitch name:" << rs.name;
        qDebug() << "index =" << rs.index << ",type =" << urf_get_type(rs.type) << ",op =" << rs.op << ",soft block =" << rs.soft << ",hard block =" << rs.hard;
    }
}
