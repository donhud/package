// Here we avoid loading the header multiple times
#ifndef Plasmoid_HEADER
#define Plasmoid_HEADER

// We need the Plasma Applet headers
#include <Plasma/Applet>

#include <QWidget>
#include <QPushButton>
#include <QObject>
#include <QList>
#include <QTimeLine>
#include <QHash>
#include <QString>
#include <QVariant>
#include <QCheckBox>
#include <QLabel>


class QSizeF;

//this is how classes in Plasma can be forward-declared
//since C++ won't allow something like:
// class Plasma::LineEdit;
//by itself..
namespace Plasma {
    class LineEdit;
    class PushButton;
    class CheckBox;
}

// Define our plasma Applet
class Plasmoid : public Plasma::Applet
{
    Q_OBJECT
    public:
        // Basic Create/Destroy
        Plasmoid(QObject *parent, const QVariantList &args);
        ~Plasmoid();

        void init();

        struct ItemObjects {
            int number;
           // QLabel *a;
            Plasma::CheckBox *b;
            //QObject *a, *b;
        };
        QHash<QObject *, ItemObjects > hash;

    private:
        Plasma::LineEdit *m_lineEdit;
        Plasma::PushButton *m_pushButton;

    private slots:
        void changeState();
        void urfChangeBlock();
};

// This is the command that links your applet to the .desktop file
K_EXPORT_PLASMA_APPLET(killswitch-manager, Plasmoid)

#endif
