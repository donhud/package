/* Source: http://zetcode.com/tutorials/qt4tutorial/ */
/* TODO: http://www.tuxation.com/setuid-on-shell-scripts.html */
/* GOAL: http://regmedia.co.uk/2008/05/01/lenovo_x300_8.jpg */
#include "GUI.h"
#include "killswitch.h"
#include <QApplication>
#include <qtsingleapplication.h>
#include <QWidget>
#include <QDesktopWidget>
#include <QTextStream>
#include <QPalette>
#include <qtranslator.h>
#include <QDebug>
#include <QPoint>

void centerWin(QWidget* widget) {
    int x, y;
    QPoint p;

    QDesktopWidget *desktop = QApplication::desktop();
    p = desktop->screenGeometry(desktop->primaryScreen()).center();

    x = p.x() - (widget->frameGeometry().width() / 2);
    y = p.y() - (widget->frameGeometry().height() / 2);

    widget->move(x,y);
}

int main(int argc, char *argv[])
{
/* basic GUI */
     QtSingleApplication app(argc, argv);
     if (app.isRunning()){
//only one of the following only is required, but activate windows does not raise the window.
         app.sendMessage(QString("activate"));
         app.activateWindow();
         return 0;
     }

     Q_INIT_RESOURCE(resources);
     app.setStyleSheet("QLabel { color: white } QCheckBox {color: black}");

     QTranslator appTranslator;
     qDebug() << QLocale::system().name();
     if(appTranslator.load(":/resources/lang_" + QLocale::system().name().left(2) + ".qm")) {
         qDebug() << "Lang loaded: " << QLocale::system().name().left(2);
     }else{
         qDebug() << "Loading english locale... ";
         if(appTranslator.load(":/resources/lang_en.qm"))
             qDebug() << "done!";
     }
     app.installTranslator(&appTranslator);

     GUI window;
     app.setActivationWindow(&window, true);

     window.setWindowTitle("Killswitch-Manager");
     window.show();
     /* method to center the window */
     centerWin(&window);
     QPalette Pal(window.palette());
     Pal.setColor(QPalette::Window, QColor(22,22,22));
     window.setPalette(Pal);

     window.setWindowOpacity(0.95);

     return app.exec();
}

