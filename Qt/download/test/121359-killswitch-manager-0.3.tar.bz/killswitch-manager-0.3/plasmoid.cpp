#include "plasmoid.h"
#include "killswitch.h"
#include "urf-killswitch.h"
#include <QPainter>
#include <QSizeF>
#include <QLabel>
#include <QFileInfo>
#include <QPixmap>
#include <QCheckBox>
#include <QGraphicsGridLayout>
#include <qtranslator.h>

#include <plasma/theme.h>
#include <Plasma/Label>
#include <Plasma/CheckBox>

KillswitchManager *pManager;
URfkillSwitchManager *urfManager;
bool urfkill_running;

Plasmoid::Plasmoid(QObject *parent, const QVariantList &args)
    : Plasma::Applet(parent, args),
      m_lineEdit(0), m_pushButton(0)  //don't forget to initialze your pointers to zero or *else*!!
{
    // this will get us the standard applet background, for free!
    setBackgroundHints(DefaultBackground);
    resize(200, 200);

}


Plasmoid::~Plasmoid()
{
    if (hasFailedToLaunch()) {
        // Do some cleanup here
    } else {
        // Save settings
	
    }
}


void Plasmoid::init()
{
     
  QGraphicsGridLayout *layout = new QGraphicsGridLayout(this);

  urfkill_running = urfManager->ownURfkillService();
  if (urfkill_running) {
	  urfManager = new URfkillSwitchManager;
	  urfManager->loadDevices();
  } else {
	  pManager = new KillswitchManager;
	  pManager->loadDevices();
  }

  if(urfkill_running) {
      for(int i = 0; i < urfManager->deviceList.length(); i++) {
          Plasma::Label* label = new Plasma::Label;
          QString deviceName(urfManager->urf_get_type(urfManager->deviceList[i]->urf_type));
          deviceName[0]=deviceName[0].toUpper();
          label->setText(deviceName);
          layout->addItem(label,i,1);

          Plasma::CheckBox *button = new Plasma::CheckBox;
          layout->addItem(button,i,2);
          if(urfManager->urf_get_state(urfManager->deviceList[i]->urf_index) == 1){
                  button->setChecked(1);
          }else{
                  button->setChecked(0);
          }
          connect(button, SIGNAL(toggled(bool)), this, SLOT(urfChangeBlock()));

          ItemObjects list;
          list.number = i;
          list.b = button;

          hash.insert(button,list);
      }
  } else {
      for(int i = 0; i < pManager->deviceList.length(); i++) {
          Plasma::Label* label = new Plasma::Label;
          QString deviceName(pManager->deviceList[i]->type);
          deviceName[0]=deviceName[0].toUpper();
          label->setText(deviceName);
          layout->addItem(label,i,1);

          Plasma::CheckBox *button = new Plasma::CheckBox;
          layout->addItem(button,i,2);
          if(pManager->deviceList[i]->get_state()==true){
                  button->setChecked(1);
                  //    icon->setEnabled(true);
          }else{
                  button->setChecked(0);
                  //    icon->setEnabled(false);
          }
          connect(button, SIGNAL(toggled(bool)), this, SLOT(changeState()));

          ItemObjects list;
          list.number = i;
          //list.a = icon;
          list.b = button;

          hash.insert(button,list);

          //painter->drawPixmap()
          /*
          Plasma::Label* icon = new Plasma::Label;
          QPixmap pixmap;
          pixmap = QString(":/resources/unknown.png");
          icon->setPixmap(pixmap);
          */
      }
  }

}

void Plasmoid::changeState() {
    Plasma::CheckBox* combo = qobject_cast<Plasma::CheckBox*>(sender());
    bool state = combo->isChecked();

    if (state == 0) {
        qDebug() << "Turning off " << pManager->deviceList[hash[combo].number]->type << " device ...";
        pManager->deviceList[hash[combo].number]->set_state(0); //ask for a return!!
        //hash[combo].a->setEnabled(false);
    } else {
        qDebug() << "Turning on " << pManager->deviceList[hash[combo].number]->type << " device...";
        pManager->deviceList[hash[combo].number]->set_state(1); //ask for a return!!
        //hash[combo].a->setEnabled(true);
    }
}

void Plasmoid::urfChangeBlock() {
    Plasma::CheckBox* combo = qobject_cast<Plasma::CheckBox*>(sender());
    bool state = combo->isChecked();

    if (state == 0) {
        qDebug() << "Turning" << urfManager->deviceList[hash[combo].number]->urf_name << "(" << urfManager->deviceList[hash[combo].number]->urf_index << ") off";
        urfManager->urf_set_block_idx(urfManager->deviceList[hash[combo].number]->urf_index);
        //hash[combo].a->setEnabled(false);
    } else {
        qDebug() << "Turning" << urfManager->deviceList[hash[combo].number]->urf_name << "(" << urfManager->deviceList[hash[combo].number]->urf_index << ") on";
        urfManager->urf_set_unblock_idx(urfManager->deviceList[hash[combo].number]->urf_index);
        //hash[combo].a->setEnabled(true);
    }
}

#include "plasmoid.moc"
