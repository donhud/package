#ifndef GUI_H
#define GUI_H

#include <QWidget>
#include <QPushButton>
#include <QObject>
#include <QList>
#include <QTimeLine>
#include <QHash>
#include <QString>
#include <QVariant>
#include <QCheckBox>
#include <QLabel>

class GUI : public QWidget {
    Q_OBJECT

    public:
        GUI(QWidget *parent=0);
        struct ItemObjects {
            int number;
            QLabel *a;
            QCheckBox *b;
            //QObject *a, *b;
        };
        QHash<QObject *, ItemObjects > hash;

    protected:
        void keyPressEvent(QKeyEvent * event);

    private slots:
        void onClick(int);
        void changeState();
        void urfChangeBlock();
        void urfStateChanged(uint, uint, int, uint, uint, QString);

    private:
};


#endif // GUI_H
