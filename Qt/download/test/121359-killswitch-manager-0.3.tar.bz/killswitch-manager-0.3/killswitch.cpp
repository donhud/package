#include <killswitch.h>
#include <QObject>
#include <QList>
#include <QString>
#include <QDBusInterface>
#include <QDBusReply>
#include <QDebug>

Device::Device(QString uid, QString type, QString name) {
    this->uid = uid;
    this->type = type;
    this->name = name;
}

void Device::set_state (bool a) {
    QDBusConnection conn = QDBusConnection::systemBus();
    QDBusInterface *device = new QDBusInterface("org.freedesktop.Hal",this->uid,"org.freedesktop.Hal.Device.KillSwitch", conn);
    device->call("SetPower", a);
}

bool Device::get_state() {
    QDBusConnection conn = QDBusConnection::systemBus();
    QDBusInterface *device = new QDBusInterface("org.freedesktop.Hal",this->uid,"org.freedesktop.Hal.Device.KillSwitch", conn);
    QDBusMessage msg = device->call("GetPower");
    return msg.arguments()[0].toBool();
}


void KillswitchManager::loadDevices() {
    QTextStream out(stdout);
    /* FROM: http://software.intel.com/en-us/articles/creating-power-aware-applications-on-linux-using-qt4/ */

    /* HAL stores everything on the system bus */
    QDBusConnection conn = QDBusConnection::systemBus();

    /* Connect to the HAL Manager device to find all devices */
    QDBusInterface hal("org.freedesktop.Hal","/org/freedesktop/Hal/Manager","org.freedesktop.Hal.Manager", conn);

    /* Call the FindDeviceByCapability method, passing in 'killswitch' to find all devices with the killswitch capability */
    QDBusMessage msg = hal.call("FindDeviceByCapability", "killswitch");

    /* Assuming the call worked, the device udis are returned as an array of QStrings, wrapped in a QVariant */
    QList<QVariant> devices = msg.arguments();
    QList<QVariant> dev = devices[0].toList();

    Device * pDevice;
    foreach (QVariant s, dev) {
       QDBusInterface haldev("org.freedesktop.Hal",s.toString(),"org.freedesktop.Hal.Device", conn);

       // Get the type
       QDBusMessage msg = haldev.call("GetProperty", "killswitch.type");
       QVariant type = msg.arguments()[0];

       // Get the name
       msg = haldev.call("GetProperty", "killswitch.name");
       QVariant name = msg.arguments()[0];

       qDebug() << "Device: " << type.toString();
       qDebug() << s.toStringList() << endl;

       // Create an object for every device and put it into a list
       pDevice = new Device(s.toString(), type.toString(), name.toString());
       deviceList.append(pDevice);
    }
    // qSort(deviceList.begin(), deviceList.end(), caseInsensitiveLessThan); //this does not work! FIXME!
}
