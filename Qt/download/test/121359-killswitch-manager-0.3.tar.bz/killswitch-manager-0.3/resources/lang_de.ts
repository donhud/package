<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>GUI</name>
    <message>
        <source>Device name</source>
        <translation>Gerätename</translation>
    </message>
    <message>
        <source>Wwan</source>
        <translation>Mobiles Breitband</translation>
    </message>
    <message>
        <source>Wlan</source>
        <translation>WLAN</translation>
    </message>
    <message>
        <source>Ultrawideband</source>
        <translation>Ultrabreitband</translation>
    </message>
    <message>
        <source>Uwb</source>
        <translation>Ultrabreitband</translation>
    </message>
</context>
</TS>
