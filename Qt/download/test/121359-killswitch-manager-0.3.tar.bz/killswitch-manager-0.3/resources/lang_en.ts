<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_US">
<context>
    <name>GUI</name>
    <message>
        <source>Device name</source>
        <translation>Device name</translation>
    </message>
    <message>
        <source>Wwan</source>
        <translation>Mobile Broadband</translation>
    </message>
    <message>
        <source>Wlan</source>
        <translation>Wireless LAN</translation>
    </message>
    <message>
        <source>Ultrawideband</source>
        <translation>Ultra-wideband</translation>
    </message>
    <message>
        <source>Uwb</source>
        <translation>Ultra-wideband</translation>
    </message>
</context>
</TS>
