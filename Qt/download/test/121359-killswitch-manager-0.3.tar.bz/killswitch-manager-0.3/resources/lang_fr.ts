<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr">
<context>
    <name>GUI</name>
    <message>
        <source>Device name</source>
        <translation>Nom du périphérique</translation>
    </message>
    <message>
        <source>Wwan</source>
        <translation>Haut débit mobile</translation>
    </message>
    <message>
        <source>Wlan</source>
        <translation>Wi-Fi</translation>
    </message>
    <message>
        <source>Ultrawideband</source>
        <translation>Ultra wideband (UWB)</translation>
    </message>
    <message>
        <source>Uwb</source>
        <translation>Ultra wideband (UWB)</translation>
    </message>
</context>
</TS>
