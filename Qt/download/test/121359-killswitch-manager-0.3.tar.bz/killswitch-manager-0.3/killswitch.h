#ifndef KILLSWITCH_H
#define KILLSWITCH_H

#include <QList>
#include <QString>

class Device {
  public:
    int state;
    char y;
    QString uid;
    QString type;
    QString name;
    void set_state (bool);
    bool get_state ();
    
    // definition from inside
    Device (QString, QString, QString);
};

class KillswitchManager {
  public:
    void loadDevices();
    QList<Device*> deviceList; // CAUTION make private!
};

#endif // KILLSWITCH_H
