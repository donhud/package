<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr_FR">
<context>
    <name>QKeyPushButton</name>
    <message>
        <location filename="keyboard/QKeyPushButton.cpp" line="40"/>
        <source>A</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/QKeyPushButton.cpp" line="40"/>
        <source>Z</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>Tester</name>
    <message>
        <location filename="tester.ui" line="14"/>
        <source>QLineEdit virtual keyboard Example</source>
        <translation>Exemple de clavier virtuel QLineEdit</translation>
    </message>
    <message>
        <location filename="tester.ui" line="55"/>
        <source>Open virtual keyboard!</source>
        <translation>Ouvrir le clavier virtuel !</translation>
    </message>
    <message>
        <location filename="tester.ui" line="62"/>
        <source>Hide virtual keyboard!</source>
        <translation>Fermer le clavier virtuel !</translation>
    </message>
    <message>
        <location filename="tester.cpp" line="14"/>
        <source>Focus that below without virtual keyboard TAB:</source>
        <translation>Focus en dessous possible sans la touche TAB :</translation>
    </message>
</context>
<context>
    <name>widgetKeyBoard</name>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="356"/>
        <source>0</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="357"/>
        <source>/</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="358"/>
        <source>?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="359"/>
        <source>&apos;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="387"/>
        <source>Q</source>
        <translation>A</translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="388"/>
        <source>W</source>
        <translation>Z</translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="389"/>
        <source>E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="390"/>
        <source>R</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="391"/>
        <source>T</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="392"/>
        <source>Y</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="393"/>
        <source>U</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="394"/>
        <source>I</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="395"/>
        <source>O</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="396"/>
        <source>P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="397"/>
        <source>+</source>
        <translation>^</translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="398"/>
        <source>*</source>
        <translation>$</translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="399"/>
        <source>-</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="414"/>
        <source>A</source>
        <translation>Q</translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="415"/>
        <source>S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="416"/>
        <source>D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="417"/>
        <source>F</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="418"/>
        <source>G</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="419"/>
        <source>H</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="420"/>
        <source>J</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="421"/>
        <source>K</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="422"/>
        <source>L</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="423"/>
        <source>ò</source>
        <translation>M</translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="424"/>
        <source>à</source>
        <translation>ù</translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="425"/>
        <source>ù</source>
        <translation>*</translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="426"/>
        <source>@</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="454"/>
        <source>_</source>
        <translation>&lt;</translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="455"/>
        <source>Z</source>
        <translation>W</translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="456"/>
        <source>X</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="457"/>
        <source>C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="458"/>
        <source>V</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="459"/>
        <source>B</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="460"/>
        <source>N</source>
        <translation></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="461"/>
        <source>M</source>
        <translation>,</translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="462"/>
        <source>,</source>
        <translation>;</translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="463"/>
        <source>;</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="464"/>
        <source>:</source>
        <translation>!</translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="465"/>
        <source>.</source>
        <translation></translation>
    </message>
</context>
</TS>
