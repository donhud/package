<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_US">
<context>
    <name>QKeyPushButton</name>
    <message>
        <location filename="keyboard/QKeyPushButton.cpp" line="40"/>
        <source>A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/QKeyPushButton.cpp" line="40"/>
        <source>Z</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Tester</name>
    <message>
        <location filename="tester.ui" line="14"/>
        <source>QLineEdit virtual keyboard Example</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tester.ui" line="55"/>
        <source>Open virtual keyboard!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tester.ui" line="62"/>
        <source>Hide virtual keyboard!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tester.cpp" line="14"/>
        <source>Focus that below without virtual keyboard TAB:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>widgetKeyBoard</name>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="356"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="357"/>
        <source>/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="358"/>
        <source>?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="359"/>
        <source>&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="387"/>
        <source>Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="388"/>
        <source>W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="389"/>
        <source>E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="390"/>
        <source>R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="391"/>
        <source>T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="392"/>
        <source>Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="393"/>
        <source>U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="394"/>
        <source>I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="395"/>
        <source>O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="396"/>
        <source>P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="397"/>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="398"/>
        <source>*</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="399"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="414"/>
        <source>A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="415"/>
        <source>S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="416"/>
        <source>D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="417"/>
        <source>F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="418"/>
        <source>G</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="419"/>
        <source>H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="420"/>
        <source>J</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="421"/>
        <source>K</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="422"/>
        <source>L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="423"/>
        <source>ò</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="424"/>
        <source>à</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="425"/>
        <source>ù</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="426"/>
        <source>@</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="454"/>
        <source>_</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="455"/>
        <source>Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="456"/>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="457"/>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="458"/>
        <source>V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="459"/>
        <source>B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="460"/>
        <source>N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="461"/>
        <source>M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="462"/>
        <source>,</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="463"/>
        <source>;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="464"/>
        <source>:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="keyboard/widgetKeyBoard.cpp" line="465"/>
        <source>.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
