#ifndef __T_TEST_H
#define __T_TEST_H

#ifdef _MSC_VER
#define inline __inline
#endif

#endif
